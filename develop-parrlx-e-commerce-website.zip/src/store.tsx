import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { Product, CartItem, Order, User, Review, RedeemCode, Offer } from './types';

interface StoreState {
  products: Product[];
  cart: CartItem[];
  orders: Order[];
  currentUser: User | null;
  users: User[];
  reviews: Review[];
  redeemCodes: RedeemCode[];
  offers: Offer[];
  members: User[];
  setProducts: (p: Product[]) => void;
  addProduct: (p: Product) => void;
  updateProduct: (p: Product) => void;
  removeProduct: (id: string) => void;
  addToCart: (item: CartItem) => void;
  removeFromCart: (index: number) => void;
  updateCartQuantity: (index: number, qty: number) => void;
  clearCart: () => void;
  addOrder: (order: Order) => void;
  updateOrderStatus: (orderId: string, status: Order['status']) => void;
  cancelOrder: (orderId: string) => void;
  login: (email: string, password: string) => User | null;
  signup: (user: User) => boolean;
  logout: () => void;
  addReview: (review: Review) => void;
  addRedeemCode: (code: RedeemCode) => void;
  removeRedeemCode: (id: string) => void;
  validateRedeemCode: (code: string) => RedeemCode | null;
  addOffer: (offer: Offer) => void;
  removeOffer: (id: string) => void;
  addMember: (user: User) => void;
  removeMember: (id: string) => void;
  getAllOrders: () => Order[];
  getUserOrders: (userId: string) => Order[];
}

const StoreContext = createContext<StoreState | null>(null);

function loadFromStorage<T>(key: string, defaultValue: T): T {
  try {
    const stored = localStorage.getItem(key);
    if (stored) return JSON.parse(stored);
  } catch {}
  return defaultValue;
}

function saveToStorage(key: string, value: any) {
  localStorage.setItem(key, JSON.stringify(value));
}

const defaultAdmin: User = {
  id: 'admin-1',
  name: 'PARRLX Admin',
  email: 'parrlx08@gmail.com',
  password: 'tiwari123',
  phone: '',
  role: 'admin',
  createdAt: new Date().toISOString()
};

export function StoreProvider({ children }: { children: ReactNode }) {
  const [products, setProductsState] = useState<Product[]>(() => loadFromStorage('parrlx_products', []));
  const [cart, setCart] = useState<CartItem[]>(() => loadFromStorage('parrlx_cart', []));
  const [orders, setOrders] = useState<Order[]>(() => loadFromStorage('parrlx_orders', []));
  const [currentUser, setCurrentUser] = useState<User | null>(() => loadFromStorage('parrlx_currentUser', null));
  const [users, setUsers] = useState<User[]>(() => {
    const stored = loadFromStorage<User[]>('parrlx_users', []);
    if (!stored.find(u => u.email === 'parrlx08@gmail.com')) {
      return [defaultAdmin, ...stored];
    }
    return stored;
  });
  const [reviews, setReviews] = useState<Review[]>(() => loadFromStorage('parrlx_reviews', []));
  const [redeemCodes, setRedeemCodes] = useState<RedeemCode[]>(() => loadFromStorage('parrlx_redeemCodes', []));
  const [offers, setOffers] = useState<Offer[]>(() => loadFromStorage('parrlx_offers', []));
  const [members, setMembers] = useState<User[]>(() => loadFromStorage('parrlx_members', []));

  useEffect(() => { saveToStorage('parrlx_products', products); }, [products]);
  useEffect(() => { saveToStorage('parrlx_cart', cart); }, [cart]);
  useEffect(() => { saveToStorage('parrlx_orders', orders); }, [orders]);
  useEffect(() => { saveToStorage('parrlx_currentUser', currentUser); }, [currentUser]);
  useEffect(() => { saveToStorage('parrlx_users', users); }, [users]);
  useEffect(() => { saveToStorage('parrlx_reviews', reviews); }, [reviews]);
  useEffect(() => { saveToStorage('parrlx_redeemCodes', redeemCodes); }, [redeemCodes]);
  useEffect(() => { saveToStorage('parrlx_offers', offers); }, [offers]);
  useEffect(() => { saveToStorage('parrlx_members', members); }, [members]);

  const setProducts = (p: Product[]) => setProductsState(p);
  const addProduct = (p: Product) => setProductsState(prev => [...prev, p]);
  const updateProduct = (p: Product) => setProductsState(prev => prev.map(x => x.id === p.id ? p : x));
  const removeProduct = (id: string) => setProductsState(prev => prev.filter(x => x.id !== id));

  const addToCart = (item: CartItem) => {
    setCart(prev => {
      const existing = prev.findIndex(c => c.product.id === item.product.id && c.size === item.size && c.color === item.color);
      if (existing >= 0) {
        const updated = [...prev];
        updated[existing].quantity += item.quantity;
        return updated;
      }
      return [...prev, item];
    });
  };
  const removeFromCart = (index: number) => setCart(prev => prev.filter((_, i) => i !== index));
  const updateCartQuantity = (index: number, qty: number) => setCart(prev => {
    const updated = [...prev];
    if (updated[index]) updated[index].quantity = qty;
    return updated;
  });
  const clearCart = () => setCart([]);

  const addOrder = (order: Order) => setOrders(prev => [order, ...prev]);
  const updateOrderStatus = (orderId: string, status: Order['status']) => {
    setOrders(prev => prev.map(o => o.id === orderId ? { ...o, status } : o));
  };
  const cancelOrder = (orderId: string) => {
    setOrders(prev => prev.map(o => o.id === orderId ? { ...o, status: 'cancelled' } : o));
  };

  const login = (email: string, password: string): User | null => {
    const user = users.find(u => u.email.toLowerCase() === email.toLowerCase() && u.password === password);
    if (user) {
      setCurrentUser(user);
      return user;
    }
    // Check members
    const member = members.find(u => u.email.toLowerCase() === email.toLowerCase() && u.password === password);
    if (member) {
      setCurrentUser(member);
      return member;
    }
    return null;
  };

  const signup = (user: User): boolean => {
    if (users.find(u => u.email.toLowerCase() === user.email.toLowerCase())) return false;
    if (members.find(u => u.email.toLowerCase() === user.email.toLowerCase())) return false;
    setUsers(prev => [...prev, user]);
    setCurrentUser(user);
    return true;
  };

  const logout = () => {
    setCurrentUser(null);
    setCart([]);
  };

  const addReview = (review: Review) => setReviews(prev => [...prev, review]);
  const addRedeemCode = (code: RedeemCode) => setRedeemCodes(prev => [...prev, code]);
  const removeRedeemCode = (id: string) => setRedeemCodes(prev => prev.filter(c => c.id !== id));
  const validateRedeemCode = (code: string): RedeemCode | null => {
    return redeemCodes.find(c => c.code.toLowerCase() === code.toLowerCase() && c.active) || null;
  };
  const addOffer = (offer: Offer) => setOffers(prev => [...prev, offer]);
  const removeOffer = (id: string) => setOffers(prev => prev.filter(o => o.id !== id));
  const addMember = (user: User) => {
    setMembers(prev => [...prev, user]);
    setUsers(prev => [...prev, user]);
  };
  const removeMember = (id: string) => {
    setMembers(prev => prev.filter(m => m.id !== id));
  };
  const getAllOrders = () => orders;
  const getUserOrders = (userId: string) => orders.filter(o => o.userId === userId);

  return (
    <StoreContext.Provider value={{
      products, cart, orders, currentUser, users, reviews, redeemCodes, offers, members,
      setProducts, addProduct, updateProduct, removeProduct,
      addToCart, removeFromCart, updateCartQuantity, clearCart,
      addOrder, updateOrderStatus, cancelOrder,
      login, signup, logout,
      addReview, addRedeemCode, removeRedeemCode, validateRedeemCode,
      addOffer, removeOffer, addMember, removeMember,
      getAllOrders, getUserOrders
    }}>
      {children}
    </StoreContext.Provider>
  );
}

export function useStore() {
  const ctx = useContext(StoreContext);
  if (!ctx) throw new Error('useStore must be used inside StoreProvider');
  return ctx;
}
