import { HashRouter as Router, Routes, Route } from 'react-router-dom';
import { StoreProvider } from './store';
import Layout from './components/Layout';
import Home from './pages/Home';
import Store from './pages/Store';
import ProductDetail from './pages/ProductDetail';
import Cart from './pages/Cart';
import Checkout from './pages/Checkout';
import Login from './pages/Login';
import Signup from './pages/Signup';
import Profile from './pages/Profile';
import TrackOrder from './pages/TrackOrder';
import OrderHistory from './pages/OrderHistory';
import HelpSupport from './pages/HelpSupport';
import AdminDashboard from './pages/AdminDashboard';
import AdminProducts from './pages/AdminProducts';
import AdminOrders from './pages/AdminOrders';
import AdminRedeemCodes from './pages/AdminRedeemCodes';
import AdminOffers from './pages/AdminOffers';
import AdminMembers from './pages/AdminMembers';
import AdminUsers from './pages/AdminUsers';
import AdminAnalytics from './pages/AdminAnalytics';

export default function App() {
  return (
    <StoreProvider>
      <Router>
        <Routes>
          <Route path="/" element={<Layout />}>
            <Route index element={<Home />} />
            <Route path="store" element={<Store />} />
            <Route path="product/:id" element={<ProductDetail />} />
            <Route path="cart" element={<Cart />} />
            <Route path="checkout" element={<Checkout />} />
            <Route path="login" element={<Login />} />
            <Route path="signup" element={<Signup />} />
            <Route path="profile" element={<Profile />} />
            <Route path="track-order" element={<TrackOrder />} />
            <Route path="order-history" element={<OrderHistory />} />
            <Route path="help" element={<HelpSupport />} />
            <Route path="admin" element={<AdminDashboard />} />
            <Route path="admin/products" element={<AdminProducts />} />
            <Route path="admin/orders" element={<AdminOrders />} />
            <Route path="admin/redeem-codes" element={<AdminRedeemCodes />} />
            <Route path="admin/offers" element={<AdminOffers />} />
            <Route path="admin/members" element={<AdminMembers />} />
            <Route path="admin/users" element={<AdminUsers />} />
            <Route path="admin/analytics" element={<AdminAnalytics />} />
          </Route>
        </Routes>
      </Router>
    </StoreProvider>
  );
}
