import { useNavigate } from 'react-router-dom';
import { useStore } from '../store';

export default function AdminUsers() {
  const { currentUser, users, members } = useStore();
  const navigate = useNavigate();

  if (!currentUser || currentUser.role !== 'admin') {
    navigate('/login'); return null;
  }

  // Only show customer and member accounts, not admin
  const allAccounts = [...users, ...members.filter(m => !users.find(u => u.id === m.id))].filter(u => u.role !== 'admin');

  return (
    <div className="max-w-6xl mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-6">👤 All User Accounts</h1>
      <p className="text-gray-500 mb-6">Total registered users: {allAccounts.length} (Customers & Team Members only)</p>

      <div className="bg-white rounded-xl shadow overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="bg-gray-50">
            <tr>
              <th className="text-left p-3">#</th>
              <th className="text-left p-3">Name</th>
              <th className="text-left p-3">Email</th>
              <th className="text-left p-3">Password</th>
              <th className="text-left p-3">Phone</th>
              <th className="text-left p-3">Role</th>
              <th className="text-left p-3">Joined</th>
            </tr>
          </thead>
          <tbody>
            {allAccounts.map((user, i) => (
              <tr key={user.id} className="border-t hover:bg-gray-50">
                <td className="p-3 text-gray-500">{i + 1}</td>
                <td className="p-3 font-medium">{user.name}</td>
                <td className="p-3">{user.email}</td>
                <td className="p-3 font-mono text-xs">{user.password}</td>
                <td className="p-3">{user.phone || '-'}</td>
                <td className="p-3">
                  <span className={`px-2 py-0.5 rounded-full text-xs font-bold ${
                    user.role === 'admin' ? 'bg-red-100 text-red-700' :
                    user.role === 'member' ? 'bg-blue-100 text-blue-700' :
                    'bg-green-100 text-green-700'
                  }`}>{user.role}</span>
                </td>
                <td className="p-3 text-gray-500">{new Date(user.createdAt).toLocaleDateString()}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
