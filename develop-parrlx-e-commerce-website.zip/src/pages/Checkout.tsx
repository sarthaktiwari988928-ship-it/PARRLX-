import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useStore } from '../store';
import { Order, ShippingDetails } from '../types';

export default function Checkout() {
  const { cart, currentUser, clearCart, addOrder, validateRedeemCode } = useStore();
  const navigate = useNavigate();

  const [paymentMethod, setPaymentMethod] = useState<'online' | 'cod'>('cod');
  const [redeemInput, setRedeemInput] = useState('');
  const [discount, setDiscount] = useState(0);
  const [appliedCode, setAppliedCode] = useState('');
  const [loading, setLoading] = useState(false);
  const [shipping, setShipping] = useState<ShippingDetails>({
    fullName: currentUser?.name || '',
    email: currentUser?.email || '',
    phone: currentUser?.phone || '',
    address: '',
    city: '',
    state: '',
    pincode: ''
  });

  if (!currentUser) {
    navigate('/login');
    return null;
  }

  if (cart.length === 0) {
    navigate('/cart');
    return null;
  }

  const subtotal = cart.reduce((sum, item) => sum + item.product.price * item.quantity, 0);
  const discountAmount = Math.round(subtotal * discount / 100);
  const total = subtotal - discountAmount;

  const handleApplyCode = () => {
    const code = validateRedeemCode(redeemInput);
    if (code) {
      setDiscount(code.discountPercent);
      setAppliedCode(code.code);
      alert(`Code applied! ${code.discountPercent}% discount`);
    } else {
      alert('Invalid or expired code');
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setShipping(prev => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const sendOrderEmail = async (order: Order) => {
    const itemsList = order.items.map(item =>
      `${item.product.name} (Size: ${item.size}, Color: ${item.color}, Qty: ${item.quantity}) - ₹${item.product.price * item.quantity}`
    ).join('\n');

    const emailBody = `
NEW ORDER - PARRLX

Order ID: ${order.id}
Date: ${new Date(order.date).toLocaleString()}

Customer Details:
Name: ${order.shippingDetails.fullName}
Email: ${order.shippingDetails.email}
Phone: ${order.shippingDetails.phone}
Address: ${order.shippingDetails.address}, ${order.shippingDetails.city}, ${order.shippingDetails.state} - ${order.shippingDetails.pincode}

Payment Method: ${order.paymentMethod === 'cod' ? 'Cash on Delivery' : 'Online Payment'}

Items:
${itemsList}

Subtotal: ₹${order.total + order.discount}
Discount: ₹${order.discount} ${order.redeemCode ? `(Code: ${order.redeemCode})` : ''}
Total: ₹${order.total}

Status: ${order.status.toUpperCase()}
    `.trim();

    // Using FormSubmit.co to send email
    try {
      const formData = new FormData();
      formData.append('email', 'parrlx08@gmail.com');
      formData.append('_subject', `New PARRLX Order #${order.id}`);
      formData.append('Order ID', order.id);
      formData.append('Customer Name', order.shippingDetails.fullName);
      formData.append('Customer Email', order.shippingDetails.email);
      formData.append('Customer Phone', order.shippingDetails.phone);
      formData.append('Shipping Address', `${order.shippingDetails.address}, ${order.shippingDetails.city}, ${order.shippingDetails.state} - ${order.shippingDetails.pincode}`);
      formData.append('Payment Method', order.paymentMethod === 'cod' ? 'Cash on Delivery' : 'Online Payment');
      formData.append('Items', itemsList);
      formData.append('Subtotal', `₹${order.total + order.discount}`);
      formData.append('Discount', `₹${order.discount}`);
      formData.append('Total', `₹${order.total}`);
      formData.append('Status', order.status);
      formData.append('message', emailBody);
      formData.append('_captcha', 'false');
      formData.append('_template', 'table');

      await fetch('https://formsubmit.co/ajax/parrlx08@gmail.com', {
        method: 'POST',
        body: formData
      });
    } catch (err) {
      console.log('Email sending attempted', err);
    }
  };

  const handlePlaceOrder = async () => {
    if (!shipping.fullName || !shipping.phone || !shipping.address || !shipping.city || !shipping.state || !shipping.pincode) {
      alert('Please fill all shipping details');
      return;
    }

    setLoading(true);

    const order: Order = {
      id: 'ORD-' + Date.now().toString(36).toUpperCase(),
      userId: currentUser.id,
      items: [...cart],
      total,
      discount: discountAmount,
      redeemCode: appliedCode || undefined,
      shippingDetails: shipping,
      paymentMethod,
      status: 'pending',
      date: new Date().toISOString()
    };

    addOrder(order);
    await sendOrderEmail(order);
    clearCart();
    setLoading(false);
    alert(`Order placed successfully! Order ID: ${order.id}`);
    navigate('/track-order');
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-6">Checkout</h1>

      <div className="grid md:grid-cols-2 gap-8">
        {/* Shipping Details */}
        <div className="space-y-4">
          <h2 className="text-xl font-bold">Shipping Details</h2>
          <div className="bg-white rounded-xl shadow p-5 space-y-3">
            <div>
              <label className="text-sm font-medium text-gray-600">Full Name</label>
              <input name="fullName" value={shipping.fullName} onChange={handleChange}
                className="w-full border rounded-lg px-3 py-2 mt-1 focus:ring-2 focus:ring-yellow-500 focus:outline-none" />
            </div>
            <div>
              <label className="text-sm font-medium text-gray-600">Email</label>
              <input name="email" type="email" value={shipping.email} onChange={handleChange}
                className="w-full border rounded-lg px-3 py-2 mt-1 focus:ring-2 focus:ring-yellow-500 focus:outline-none" />
            </div>
            <div>
              <label className="text-sm font-medium text-gray-600">Phone</label>
              <input name="phone" value={shipping.phone} onChange={handleChange}
                className="w-full border rounded-lg px-3 py-2 mt-1 focus:ring-2 focus:ring-yellow-500 focus:outline-none" />
            </div>
            <div>
              <label className="text-sm font-medium text-gray-600">Address</label>
              <input name="address" value={shipping.address} onChange={handleChange}
                className="w-full border rounded-lg px-3 py-2 mt-1 focus:ring-2 focus:ring-yellow-500 focus:outline-none" />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-sm font-medium text-gray-600">City</label>
                <input name="city" value={shipping.city} onChange={handleChange}
                  className="w-full border rounded-lg px-3 py-2 mt-1 focus:ring-2 focus:ring-yellow-500 focus:outline-none" />
              </div>
              <div>
                <label className="text-sm font-medium text-gray-600">State</label>
                <input name="state" value={shipping.state} onChange={handleChange}
                  className="w-full border rounded-lg px-3 py-2 mt-1 focus:ring-2 focus:ring-yellow-500 focus:outline-none" />
              </div>
            </div>
            <div>
              <label className="text-sm font-medium text-gray-600">Pincode</label>
              <input name="pincode" value={shipping.pincode} onChange={handleChange}
                className="w-full border rounded-lg px-3 py-2 mt-1 focus:ring-2 focus:ring-yellow-500 focus:outline-none" />
            </div>
          </div>

          {/* Payment Method */}
          <h2 className="text-xl font-bold pt-4">Payment Method</h2>
          <div className="bg-white rounded-xl shadow p-5 space-y-3">
            <label className="flex items-center gap-3 p-3 border rounded-lg cursor-pointer hover:bg-gray-50">
              <input type="radio" name="payment" checked={paymentMethod === 'cod'} onChange={() => setPaymentMethod('cod')} className="accent-yellow-500" />
              <div>
                <p className="font-bold">💵 Cash on Delivery</p>
                <p className="text-sm text-gray-500">Pay when you receive</p>
              </div>
            </label>
            <label className="flex items-center gap-3 p-3 border rounded-lg cursor-pointer hover:bg-gray-50">
              <input type="radio" name="payment" checked={paymentMethod === 'online'} onChange={() => setPaymentMethod('online')} className="accent-yellow-500" />
              <div>
                <p className="font-bold">📱 Online Payment (UPI/QR)</p>
                <p className="text-sm text-gray-500">Scan QR code to pay</p>
              </div>
            </label>

            {paymentMethod === 'online' && (
              <div className="text-center py-4 border-t mt-4">
                <p className="font-bold mb-3">Scan QR Code to Pay ₹{total}</p>
                <img src="https://i.ibb.co/Ngh567zf/Account-QRCode-Bank-Of-India-7310-DARK-THEME.png" alt="Payment QR Code"
                  className="mx-auto w-48 h-48 rounded-lg shadow-lg" />
                <p className="text-sm text-gray-500 mt-2">After payment, click "Place Order"</p>
              </div>
            )}
          </div>
        </div>

        {/* Order Summary */}
        <div>
          <h2 className="text-xl font-bold mb-4">Order Summary</h2>
          <div className="bg-white rounded-xl shadow p-5 space-y-4">
            {cart.map((item, i) => (
              <div key={i} className="flex gap-3 pb-3 border-b last:border-0">
                <div className="w-16 h-16 bg-gray-100 rounded overflow-hidden flex-shrink-0">
                  <img src={item.product.image} alt="" className="w-full h-full object-cover" />
                </div>
                <div className="flex-1">
                  <p className="font-medium text-sm">{item.product.name}</p>
                  <p className="text-xs text-gray-500">{item.size} | {item.color} × {item.quantity}</p>
                </div>
                <p className="font-bold">₹{item.product.price * item.quantity}</p>
              </div>
            ))}

            {/* Redeem Code */}
            <div className="border-t pt-3">
              <label className="text-sm font-medium">Redeem Code</label>
              <div className="flex gap-2 mt-1">
                <input value={redeemInput} onChange={e => setRedeemInput(e.target.value)} placeholder="Enter code"
                  className="flex-1 border rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-yellow-500 focus:outline-none" />
                <button onClick={handleApplyCode} className="bg-black text-white px-4 py-2 rounded-lg text-sm font-bold hover:bg-gray-800">Apply</button>
              </div>
              {appliedCode && <p className="text-green-600 text-sm mt-1">✅ Code "{appliedCode}" applied - {discount}% off</p>}
            </div>

            <div className="border-t pt-3 space-y-2">
              <div className="flex justify-between text-sm">
                <span>Subtotal</span>
                <span>₹{subtotal}</span>
              </div>
              {discountAmount > 0 && (
                <div className="flex justify-between text-sm text-green-600">
                  <span>Discount</span>
                  <span>-₹{discountAmount}</span>
                </div>
              )}
              <div className="flex justify-between text-sm">
                <span>Shipping</span>
                <span className="text-green-600">Free</span>
              </div>
              <div className="flex justify-between text-xl font-bold border-t pt-2">
                <span>Total</span>
                <span className="text-green-600">₹{total}</span>
              </div>
            </div>

            <button onClick={handlePlaceOrder} disabled={loading}
              className="w-full bg-yellow-500 text-black py-3 rounded-lg font-bold text-lg hover:bg-yellow-400 transition disabled:opacity-50">
              {loading ? '⏳ Placing Order...' : '✅ Place Order'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
