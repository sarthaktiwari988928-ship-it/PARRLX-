import { useParams, useNavigate } from 'react-router-dom';
import { useStore } from '../store';
import { useState } from 'react';

export default function ProductDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { products, addToCart, currentUser, reviews, addReview } = useStore();
  const product = products.find(p => p.id === id);

  const [selectedSize, setSelectedSize] = useState('');
  const [selectedColor, setSelectedColor] = useState('');
  const [qty, setQty] = useState(1);
  const [reviewText, setReviewText] = useState('');
  const [reviewRating, setReviewRating] = useState(5);

  if (!product) {
    return <div className="max-w-4xl mx-auto px-4 py-16 text-center"><h2 className="text-2xl font-bold">Product not found</h2></div>;
  }

  const productReviews = reviews.filter(r => r.productId === product.id);
  const size = selectedSize || product.sizes[0] || 'M';
  const color = selectedColor || product.colors[0] || 'Black';

  const handleAddToCart = () => {
    if (!currentUser) { navigate('/login'); return; }
    addToCart({ product, quantity: qty, size, color });
    alert('Added to cart!');
  };

  const handleBuyNow = () => {
    if (!currentUser) { navigate('/login'); return; }
    addToCart({ product, quantity: qty, size, color });
    navigate('/checkout');
  };

  const handleShare = () => {
    const url = window.location.href;
    if (navigator.share) {
      navigator.share({ title: product.name, text: `Check out ${product.name} on PARRLX!`, url });
    } else {
      navigator.clipboard.writeText(url);
      alert('Product link copied!');
    }
  };

  const handleReview = () => {
    if (!currentUser) { navigate('/login'); return; }
    if (!reviewText.trim()) return;
    addReview({
      id: Date.now().toString(),
      productId: product.id,
      userId: currentUser.id,
      userName: currentUser.name,
      rating: reviewRating,
      comment: reviewText,
      date: new Date().toISOString()
    });
    setReviewText('');
    setReviewRating(5);
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <button onClick={() => navigate(-1)} className="text-gray-500 hover:text-black mb-4 inline-block">← Back</button>

      <div className="bg-white rounded-xl shadow-lg overflow-hidden flex flex-col md:flex-row">
        <div className="md:w-1/2 h-80 md:h-auto bg-gray-100">
          <img src={product.image} alt={product.name} className="w-full h-full object-cover" />
        </div>
        <div className="p-6 md:w-1/2 space-y-4">
          <h1 className="text-3xl font-bold">{product.name}</h1>
          <p className="text-gray-500">{product.category}</p>
          <p className="text-gray-600">{product.description}</p>
          <div className="flex items-center gap-3">
            <span className="text-3xl font-bold text-green-600">₹{product.price}</span>
            {product.originalPrice && product.originalPrice > product.price && (
              <>
                <span className="text-lg text-gray-400 line-through">₹{product.originalPrice}</span>
                <span className="bg-red-100 text-red-600 px-2 py-0.5 rounded-full text-sm font-bold">
                  {Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100)}% OFF
                </span>
              </>
            )}
          </div>

          {/* Size */}
          {product.sizes.length > 0 && (
            <div>
              <label className="font-semibold text-sm">Size</label>
              <div className="flex gap-2 mt-1">
                {product.sizes.map(s => (
                  <button key={s} onClick={() => setSelectedSize(s)}
                    className={`px-4 py-2 border rounded-lg text-sm font-medium ${size === s ? 'bg-black text-white' : 'hover:bg-gray-100'}`}>
                    {s}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Color */}
          {product.colors.length > 0 && (
            <div>
              <label className="font-semibold text-sm">Color</label>
              <div className="flex gap-2 mt-1">
                {product.colors.map(c => (
                  <button key={c} onClick={() => setSelectedColor(c)}
                    className={`px-4 py-2 border rounded-lg text-sm font-medium ${color === c ? 'bg-black text-white' : 'hover:bg-gray-100'}`}>
                    {c}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Qty */}
          <div>
            <label className="font-semibold text-sm">Quantity</label>
            <div className="flex items-center gap-2 mt-1">
              <button onClick={() => setQty(Math.max(1, qty - 1))} className="w-8 h-8 border rounded flex items-center justify-center hover:bg-gray-100">-</button>
              <span className="w-10 text-center font-bold">{qty}</span>
              <button onClick={() => setQty(qty + 1)} className="w-8 h-8 border rounded flex items-center justify-center hover:bg-gray-100">+</button>
            </div>
          </div>

          <div className="flex gap-3 pt-2">
            <button onClick={handleAddToCart} className="flex-1 bg-black text-white py-3 rounded-lg font-bold hover:bg-gray-800 transition">
              🛒 Add to Cart
            </button>
            <button onClick={handleBuyNow} className="flex-1 bg-yellow-500 text-black py-3 rounded-lg font-bold hover:bg-yellow-400 transition">
              ⚡ Buy Now
            </button>
          </div>
          <button onClick={handleShare} className="w-full border border-gray-300 py-2 rounded-lg text-sm hover:bg-gray-100 transition">📤 Share Product</button>
        </div>
      </div>

      {/* Reviews Section */}
      <div className="mt-10">
        <h2 className="text-2xl font-bold mb-4">Reviews ({productReviews.length})</h2>

        {currentUser && (
          <div className="bg-white rounded-xl p-5 shadow mb-6 space-y-3">
            <h3 className="font-semibold">Write a Review</h3>
            <div className="flex gap-1">
              {[1, 2, 3, 4, 5].map(i => (
                <button key={i} onClick={() => setReviewRating(i)} className="text-2xl">
                  {i <= reviewRating ? '⭐' : '☆'}
                </button>
              ))}
            </div>
            <textarea value={reviewText} onChange={e => setReviewText(e.target.value)} placeholder="Share your experience..."
              className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-yellow-500 focus:outline-none" rows={3} />
            <button onClick={handleReview} className="bg-black text-white px-6 py-2 rounded-lg font-bold hover:bg-gray-800">Submit Review</button>
          </div>
        )}

        {productReviews.length === 0 ? (
          <p className="text-gray-500 text-center py-8">No reviews yet. Be the first to review!</p>
        ) : (
          <div className="space-y-4">
            {productReviews.map(r => (
              <div key={r.id} className="bg-white rounded-xl p-4 shadow">
                <div className="flex items-center justify-between">
                  <span className="font-bold">{r.userName}</span>
                  <span className="text-xs text-gray-400">{new Date(r.date).toLocaleDateString()}</span>
                </div>
                <div className="text-sm mt-1">{'⭐'.repeat(r.rating)}</div>
                <p className="text-gray-600 mt-2">{r.comment}</p>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
