import { Link, useNavigate } from 'react-router-dom';
import { useStore } from '../store';

export default function Profile() {
  const { currentUser, logout } = useStore();
  const navigate = useNavigate();

  if (!currentUser) {
    navigate('/login');
    return null;
  }

  const isAdmin = currentUser.role === 'admin';
  const isMember = currentUser.role === 'member';

  return (
    <div className="max-w-2xl mx-auto px-4 py-8">
      <div className="bg-white rounded-2xl shadow-xl p-8">
        <div className="text-center mb-6">
          <div className="w-20 h-20 bg-black text-white rounded-full flex items-center justify-center text-3xl mx-auto mb-3 font-bold">
            {currentUser.name.charAt(0).toUpperCase()}
          </div>
          <h1 className="text-2xl font-bold">{currentUser.name}</h1>
          <p className="text-gray-500">{currentUser.email}</p>
          {currentUser.phone && <p className="text-gray-500 text-sm">{currentUser.phone}</p>}
          <span className={`inline-block mt-2 px-3 py-1 rounded-full text-xs font-bold ${
            isAdmin ? 'bg-red-100 text-red-600' : isMember ? 'bg-blue-100 text-blue-600' : 'bg-green-100 text-green-600'
          }`}>
            {isAdmin ? '👑 Admin' : isMember ? '🏷️ Team Member' : '👤 Customer'}
          </span>
        </div>

        <div className="grid gap-3">
          <Link to="/" className="flex items-center gap-3 p-3 border rounded-lg hover:bg-gray-50 transition">
            <span className="text-xl">🏠</span>
            <span className="font-medium">Home</span>
          </Link>
          <Link to="/store" className="flex items-center gap-3 p-3 border rounded-lg hover:bg-gray-50 transition">
            <span className="text-xl">🏪</span>
            <span className="font-medium">Store</span>
          </Link>

          {!isAdmin && (
            <>
              <Link to="/cart" className="flex items-center gap-3 p-3 border rounded-lg hover:bg-gray-50 transition">
                <span className="text-xl">🛒</span>
                <span className="font-medium">My Cart</span>
              </Link>
              <Link to="/track-order" className="flex items-center gap-3 p-3 border rounded-lg hover:bg-gray-50 transition">
                <span className="text-xl">📦</span>
                <span className="font-medium">Track Order</span>
              </Link>
              <Link to="/order-history" className="flex items-center gap-3 p-3 border rounded-lg hover:bg-gray-50 transition">
                <span className="text-xl">📋</span>
                <span className="font-medium">Order History</span>
              </Link>
            </>
          )}

          {(isAdmin || isMember) && (
            <Link to="/admin" className="flex items-center gap-3 p-3 border rounded-lg hover:bg-gray-50 transition">
              <span className="text-xl">📊</span>
              <span className="font-medium">Dashboard</span>
            </Link>
          )}

          <Link to="/help" className="flex items-center gap-3 p-3 border rounded-lg hover:bg-gray-50 transition">
            <span className="text-xl">❓</span>
            <span className="font-medium">Help & Support</span>
          </Link>

          {/* WhatsApp */}
          <a href="https://wa.me/919415029404" target="_blank" rel="noreferrer" className="flex items-center gap-3 p-3 border rounded-lg hover:bg-green-50 transition">
            <span className="text-xl">💬</span>
            <span className="font-medium text-green-600">WhatsApp: +91 9415029404</span>
          </a>

          {/* Phone */}
          <a href="tel:+919335177136" className="flex items-center gap-3 p-3 border rounded-lg hover:bg-blue-50 transition">
            <span className="text-xl">📞</span>
            <span className="font-medium text-blue-600">Call: +91 93351 77136</span>
          </a>
        </div>

        <button onClick={() => { logout(); navigate('/'); }}
          className="w-full mt-6 bg-red-600 text-white py-3 rounded-lg font-bold hover:bg-red-700 transition">
          Logout
        </button>
      </div>
    </div>
  );
}
