import { useNavigate } from 'react-router-dom';
import { useStore } from '../store';

export default function AdminAnalytics() {
  const { currentUser, getAllOrders, products, users, reviews } = useStore();
  const navigate = useNavigate();

  if (!currentUser || currentUser.role !== 'admin') {
    navigate('/login'); return null;
  }

  const orders = getAllOrders();
  const completedOrders = orders.filter(o => o.status !== 'cancelled');
  const totalSales = completedOrders.reduce((sum, o) => sum + o.total, 0);
  const totalProfit = Math.round(totalSales * 0.3);
  const avgOrderValue = completedOrders.length > 0 ? Math.round(totalSales / completedOrders.length) : 0;
  const totalCustomers = users.filter(u => u.role === 'customer').length;
  const totalReviews = reviews.length;
  const avgRating = reviews.length > 0 ? (reviews.reduce((sum, r) => sum + r.rating, 0) / reviews.length).toFixed(1) : '0';

  // Sales by category
  const categorySales: Record<string, number> = {};
  completedOrders.forEach(o => {
    o.items.forEach(item => {
      const cat = item.product.category || 'Other';
      categorySales[cat] = (categorySales[cat] || 0) + item.product.price * item.quantity;
    });
  });

  // Monthly orders
  const monthlyOrders: Record<string, number> = {};
  orders.forEach(o => {
    const month = new Date(o.date).toLocaleDateString('en-US', { month: 'short', year: 'numeric' });
    monthlyOrders[month] = (monthlyOrders[month] || 0) + 1;
  });

  // Payment method distribution
  const codOrders = orders.filter(o => o.paymentMethod === 'cod').length;
  const onlineOrders = orders.filter(o => o.paymentMethod === 'online').length;

  // Top selling products
  const productSales: Record<string, { name: string; qty: number; revenue: number }> = {};
  completedOrders.forEach(o => {
    o.items.forEach(item => {
      if (!productSales[item.product.id]) {
        productSales[item.product.id] = { name: item.product.name, qty: 0, revenue: 0 };
      }
      productSales[item.product.id].qty += item.quantity;
      productSales[item.product.id].revenue += item.product.price * item.quantity;
    });
  });
  const topProducts = Object.values(productSales).sort((a, b) => b.revenue - a.revenue).slice(0, 5);

  return (
    <div className="max-w-6xl mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-8">📊 Analytics Center</h1>

      {/* Key Metrics */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
        <div className="bg-white rounded-xl shadow p-5 text-center">
          <p className="text-3xl font-bold text-green-600">₹{totalSales.toLocaleString()}</p>
          <p className="text-sm text-gray-500">Total Revenue</p>
        </div>
        <div className="bg-white rounded-xl shadow p-5 text-center">
          <p className="text-3xl font-bold text-purple-600">₹{totalProfit.toLocaleString()}</p>
          <p className="text-sm text-gray-500">Est. Profit (30%)</p>
        </div>
        <div className="bg-white rounded-xl shadow p-5 text-center">
          <p className="text-3xl font-bold text-blue-600">{orders.length}</p>
          <p className="text-sm text-gray-500">Total Orders</p>
        </div>
        <div className="bg-white rounded-xl shadow p-5 text-center">
          <p className="text-3xl font-bold text-orange-600">₹{avgOrderValue}</p>
          <p className="text-sm text-gray-500">Avg Order Value</p>
        </div>
      </div>

      <div className="grid md:grid-cols-2 gap-8 mb-8">
        {/* Customer & Product Stats */}
        <div className="bg-white rounded-xl shadow p-5">
          <h2 className="font-bold text-lg mb-4">Overview</h2>
          <div className="space-y-3">
            <div className="flex justify-between p-2 bg-gray-50 rounded">
              <span>Total Customers</span>
              <span className="font-bold">{totalCustomers}</span>
            </div>
            <div className="flex justify-between p-2 bg-gray-50 rounded">
              <span>Total Products</span>
              <span className="font-bold">{products.length}</span>
            </div>
            <div className="flex justify-between p-2 bg-gray-50 rounded">
              <span>Total Reviews</span>
              <span className="font-bold">{totalReviews}</span>
            </div>
            <div className="flex justify-between p-2 bg-gray-50 rounded">
              <span>Avg Rating</span>
              <span className="font-bold">⭐ {avgRating}</span>
            </div>
            <div className="flex justify-between p-2 bg-gray-50 rounded">
              <span>COD Orders</span>
              <span className="font-bold">{codOrders}</span>
            </div>
            <div className="flex justify-between p-2 bg-gray-50 rounded">
              <span>Online Payments</span>
              <span className="font-bold">{onlineOrders}</span>
            </div>
          </div>
        </div>

        {/* Sales by Category */}
        <div className="bg-white rounded-xl shadow p-5">
          <h2 className="font-bold text-lg mb-4">Sales by Category</h2>
          {Object.keys(categorySales).length === 0 ? (
            <p className="text-gray-500 text-center py-4">No sales data yet</p>
          ) : (
            <div className="space-y-3">
              {Object.entries(categorySales).sort(([, a], [, b]) => b - a).map(([cat, amount]) => {
                const pct = Math.round((amount / totalSales) * 100);
                return (
                  <div key={cat}>
                    <div className="flex justify-between text-sm mb-1">
                      <span className="font-medium">{cat}</span>
                      <span>₹{amount.toLocaleString()} ({pct}%)</span>
                    </div>
                    <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                      <div className="h-full bg-yellow-500 rounded-full" style={{ width: `${pct}%` }}></div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>

      <div className="grid md:grid-cols-2 gap-8">
        {/* Top Selling Products */}
        <div className="bg-white rounded-xl shadow p-5">
          <h2 className="font-bold text-lg mb-4">Top Selling Products</h2>
          {topProducts.length === 0 ? (
            <p className="text-gray-500 text-center py-4">No sales data yet</p>
          ) : (
            <div className="space-y-3">
              {topProducts.map((p, i) => (
                <div key={i} className="flex items-center justify-between p-2 bg-gray-50 rounded">
                  <div>
                    <span className="text-lg mr-2">{i === 0 ? '🥇' : i === 1 ? '🥈' : i === 2 ? '🥉' : `#${i + 1}`}</span>
                    <span className="font-medium">{p.name}</span>
                  </div>
                  <div className="text-right">
                    <p className="font-bold text-green-600">₹{p.revenue.toLocaleString()}</p>
                    <p className="text-xs text-gray-500">{p.qty} sold</p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Monthly Orders */}
        <div className="bg-white rounded-xl shadow p-5">
          <h2 className="font-bold text-lg mb-4">Orders by Month</h2>
          {Object.keys(monthlyOrders).length === 0 ? (
            <p className="text-gray-500 text-center py-4">No order data yet</p>
          ) : (
            <div className="space-y-3">
              {Object.entries(monthlyOrders).map(([month, count]) => (
                <div key={month} className="flex justify-between p-2 bg-gray-50 rounded">
                  <span className="font-medium">{month}</span>
                  <span className="font-bold">{count} orders</span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
