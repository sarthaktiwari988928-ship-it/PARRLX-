import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useStore } from '../store';

export default function AdminOrders() {
  const { currentUser, getAllOrders, updateOrderStatus, cancelOrder, users } = useStore();
  const navigate = useNavigate();
  const [filterStatus, setFilterStatus] = useState('all');

  if (!currentUser || (currentUser.role !== 'admin' && currentUser.role !== 'member')) {
    navigate('/login'); return null;
  }

  const allOrders = getAllOrders();
  const orders = filterStatus === 'all' ? allOrders : allOrders.filter(o => o.status === filterStatus);

  const handleStatusChange = (orderId: string, status: 'shipped' | 'delivered') => {
    updateOrderStatus(orderId, status);
  };

  const handleCancel = (orderId: string) => {
    if (confirm('Cancel this order?')) {
      cancelOrder(orderId);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending': return 'bg-yellow-100 text-yellow-700';
      case 'shipped': return 'bg-blue-100 text-blue-700';
      case 'delivered': return 'bg-green-100 text-green-700';
      case 'cancelled': return 'bg-red-100 text-red-700';
      default: return 'bg-gray-100 text-gray-700';
    }
  };

  return (
    <div className="max-w-6xl mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-6">Manage Orders</h1>

      {/* Filter */}
      <div className="flex gap-2 mb-6 flex-wrap">
        {['all', 'pending', 'shipped', 'delivered', 'cancelled'].map(status => (
          <button key={status} onClick={() => setFilterStatus(status)}
            className={`px-4 py-2 rounded-lg text-sm font-bold transition ${
              filterStatus === status ? 'bg-black text-white' : 'bg-white border hover:bg-gray-100'
            }`}>
            {status === 'all' ? `All (${allOrders.length})` :
             `${status.charAt(0).toUpperCase() + status.slice(1)} (${allOrders.filter(o => o.status === status).length})`}
          </button>
        ))}
      </div>

      {orders.length === 0 ? (
        <div className="text-center py-16">
          <div className="text-5xl mb-4">📦</div>
          <p className="text-gray-500">No orders found</p>
        </div>
      ) : (
        <div className="space-y-4">
          {orders.map(order => {
            const customer = users.find(u => u.id === order.userId);
            return (
              <div key={order.id} className="bg-white rounded-xl shadow-md p-5 space-y-3">
                <div className="flex flex-wrap items-start justify-between gap-2">
                  <div>
                    <p className="font-bold text-lg font-mono">{order.id}</p>
                    <p className="text-sm text-gray-500">{new Date(order.date).toLocaleString()}</p>
                  </div>
                  <span className={`px-3 py-1 rounded-full text-sm font-bold ${getStatusColor(order.status)}`}>
                    {order.status.toUpperCase()}
                  </span>
                </div>

                {/* Customer Info */}
                <div className="bg-gray-50 rounded-lg p-3 text-sm">
                  <p><strong>Customer:</strong> {customer?.name || order.shippingDetails.fullName}</p>
                  <p><strong>Email:</strong> {order.shippingDetails.email}</p>
                  <p><strong>Phone:</strong> {order.shippingDetails.phone}</p>
                  <p><strong>Address:</strong> {order.shippingDetails.address}, {order.shippingDetails.city}, {order.shippingDetails.state} - {order.shippingDetails.pincode}</p>
                  <p><strong>Payment:</strong> {order.paymentMethod === 'cod' ? 'Cash on Delivery' : 'Online Payment'}</p>
                </div>

                {/* Items */}
                <div className="border-t pt-3 space-y-2">
                  {order.items.map((item, i) => (
                    <div key={i} className="flex gap-3 items-center">
                      <div className="w-12 h-12 bg-gray-100 rounded overflow-hidden flex-shrink-0">
                        <img src={item.product.image} alt="" className="w-full h-full object-cover" />
                      </div>
                      <div className="flex-1">
                        <p className="font-medium text-sm">{item.product.name}</p>
                        <p className="text-xs text-gray-500">Size: {item.size} | Color: {item.color} | Qty: {item.quantity}</p>
                      </div>
                      <p className="font-bold text-sm">₹{item.product.price * item.quantity}</p>
                    </div>
                  ))}
                </div>

                {/* Total & Actions */}
                <div className="flex flex-wrap items-center justify-between border-t pt-3 gap-3">
                  <div>
                    {order.discount > 0 && <p className="text-sm text-green-600">Discount: -₹{order.discount} {order.redeemCode && `(${order.redeemCode})`}</p>}
                    <p className="font-bold text-xl text-green-600">Total: ₹{order.total}</p>
                  </div>
                  <div className="flex gap-2 flex-wrap">
                    {order.status === 'pending' && (
                      <>
                        <button onClick={() => handleStatusChange(order.id, 'shipped')}
                          className="bg-blue-600 text-white px-4 py-2 rounded-lg text-sm font-bold hover:bg-blue-700">
                          🚚 Mark Shipped
                        </button>
                        <button onClick={() => handleStatusChange(order.id, 'delivered')}
                          className="bg-green-600 text-white px-4 py-2 rounded-lg text-sm font-bold hover:bg-green-700">
                          ✅ Mark Delivered
                        </button>
                        <button onClick={() => handleCancel(order.id)}
                          className="bg-red-600 text-white px-4 py-2 rounded-lg text-sm font-bold hover:bg-red-700">
                          ❌ Cancel
                        </button>
                      </>
                    )}
                    {order.status === 'shipped' && (
                      <button onClick={() => handleStatusChange(order.id, 'delivered')}
                        className="bg-green-600 text-white px-4 py-2 rounded-lg text-sm font-bold hover:bg-green-700">
                        ✅ Mark Delivered
                      </button>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
