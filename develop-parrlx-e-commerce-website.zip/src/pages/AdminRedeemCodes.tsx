import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useStore } from '../store';

export default function AdminRedeemCodes() {
  const { currentUser, redeemCodes, addRedeemCode, removeRedeemCode } = useStore();
  const navigate = useNavigate();
  const [code, setCode] = useState('');
  const [discount, setDiscount] = useState('');

  if (!currentUser || currentUser.role !== 'admin') {
    navigate('/login'); return null;
  }

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    if (!code.trim() || !discount) return;
    addRedeemCode({
      id: Date.now().toString(),
      code: code.toUpperCase(),
      discountPercent: Number(discount),
      active: true,
      createdAt: new Date().toISOString()
    });
    setCode('');
    setDiscount('');
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-6">🎟️ Redeem Codes</h1>

      <div className="bg-white rounded-xl shadow-lg p-6 mb-8">
        <h2 className="text-xl font-bold mb-4">Create New Code</h2>
        <form onSubmit={handleAdd} className="flex flex-col sm:flex-row gap-3">
          <input value={code} onChange={e => setCode(e.target.value)} placeholder="Code (e.g. SAVE20)"
            className="flex-1 border rounded-lg px-4 py-2 focus:ring-2 focus:ring-yellow-500 focus:outline-none uppercase" required />
          <input type="number" value={discount} onChange={e => setDiscount(e.target.value)} placeholder="Discount %"
            className="w-32 border rounded-lg px-4 py-2 focus:ring-2 focus:ring-yellow-500 focus:outline-none" min="1" max="100" required />
          <button type="submit" className="bg-black text-white px-6 py-2 rounded-lg font-bold hover:bg-gray-800">Create</button>
        </form>
      </div>

      {redeemCodes.length === 0 ? (
        <p className="text-gray-500 text-center py-8">No redeem codes created yet</p>
      ) : (
        <div className="space-y-3">
          {redeemCodes.map(rc => (
            <div key={rc.id} className="bg-white rounded-xl shadow p-4 flex items-center justify-between">
              <div>
                <p className="font-bold font-mono text-lg">{rc.code}</p>
                <p className="text-sm text-gray-500">{rc.discountPercent}% discount • Created {new Date(rc.createdAt).toLocaleDateString()}</p>
              </div>
              <div className="flex gap-2 items-center">
                <span className={`px-2 py-0.5 rounded-full text-xs font-bold ${rc.active ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-500'}`}>
                  {rc.active ? 'Active' : 'Inactive'}
                </span>
                <button onClick={() => removeRedeemCode(rc.id)} className="bg-red-600 text-white px-3 py-1.5 rounded-lg text-sm font-bold hover:bg-red-700">Remove</button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
