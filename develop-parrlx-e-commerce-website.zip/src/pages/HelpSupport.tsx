import { useState } from 'react';

interface ChatMessage {
  role: 'user' | 'bot';
  text: string;
}

const faqResponses: Record<string, string> = {
  'order': 'You can track your order from the "Track Order" section in your profile. If you need further help, contact us on WhatsApp.',
  'delivery': 'We typically deliver within 5-7 business days. Free shipping on orders above ₹999!',
  'return': 'We offer 7-day hassle-free returns. Contact us within 7 days of delivery for returns.',
  'payment': 'We accept Cash on Delivery and Online Payment (UPI). Scan QR code during checkout for online payment.',
  'cancel': 'You can cancel pending orders from the "Track Order" section. Click the "Cancel Order" button.',
  'size': 'Check the size chart on each product page. If unsure, we recommend ordering one size up.',
  'discount': 'Check for active offers on our home page. You can also use redeem codes during checkout!',
  'contact': 'WhatsApp: +91 9415029404 | Call: +91 93351 77136 | Email: parrlx08@gmail.com',
  'refund': 'Refunds are processed within 5-7 business days after the return is received.',
  'account': 'You can create an account by clicking "Sign Up". You need an account to place orders.',
  'hello': 'Hello! Welcome to PARRLX. How can I help you today? Ask about orders, delivery, returns, or anything else!',
  'hi': 'Hi there! 👋 Welcome to PARRLX support. How can I assist you?',
  'help': 'I can help you with: Orders, Delivery, Returns, Payments, Size Guide, Discounts, and more. Just ask!',
};

function getBotResponse(input: string): string {
  const lower = input.toLowerCase();
  for (const [key, response] of Object.entries(faqResponses)) {
    if (lower.includes(key)) return response;
  }
  return "I'm not sure about that. Please contact us on WhatsApp (+91 9415029404) or call +91 93351 77136 for personalized assistance. You can also email us at parrlx08@gmail.com.";
}

export default function HelpSupport() {
  const [messages, setMessages] = useState<ChatMessage[]>([
    { role: 'bot', text: 'Hello! 👋 Welcome to PARRLX Support. How can I help you today? You can ask about orders, delivery, returns, payments, and more!' }
  ]);
  const [input, setInput] = useState('');

  const handleSend = () => {
    if (!input.trim()) return;
    const userMsg: ChatMessage = { role: 'user', text: input };
    const botMsg: ChatMessage = { role: 'bot', text: getBotResponse(input) };
    setMessages(prev => [...prev, userMsg, botMsg]);
    setInput('');
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-6">Help & Support</h1>

      <div className="grid md:grid-cols-2 gap-8">
        {/* Contact Info */}
        <div className="space-y-4">
          <div className="bg-white rounded-xl shadow p-5">
            <h2 className="text-xl font-bold mb-4">Contact Us</h2>
            <div className="space-y-3">
              <a href="https://wa.me/919415029404" target="_blank" rel="noreferrer"
                className="flex items-center gap-3 p-3 bg-green-50 rounded-lg hover:bg-green-100 transition">
                <span className="text-2xl">💬</span>
                <div>
                  <p className="font-bold text-green-700">WhatsApp</p>
                  <p className="text-sm text-green-600">+91 9415029404</p>
                </div>
              </a>
              <a href="tel:+919335177136"
                className="flex items-center gap-3 p-3 bg-blue-50 rounded-lg hover:bg-blue-100 transition">
                <span className="text-2xl">📞</span>
                <div>
                  <p className="font-bold text-blue-700">Phone Call</p>
                  <p className="text-sm text-blue-600">+91 93351 77136</p>
                </div>
              </a>
              <a href="mailto:parrlx08@gmail.com"
                className="flex items-center gap-3 p-3 bg-purple-50 rounded-lg hover:bg-purple-100 transition">
                <span className="text-2xl">📧</span>
                <div>
                  <p className="font-bold text-purple-700">Email</p>
                  <p className="text-sm text-purple-600">parrlx08@gmail.com</p>
                </div>
              </a>
            </div>
          </div>

          <div className="bg-white rounded-xl shadow p-5">
            <h2 className="text-xl font-bold mb-4">FAQ</h2>
            <div className="space-y-3">
              {[
                { q: 'How do I track my order?', a: 'Go to Track Order from your profile or navigation menu.' },
                { q: 'What payment methods do you accept?', a: 'We accept Cash on Delivery and Online Payment (UPI/QR).' },
                { q: 'How long does delivery take?', a: 'Standard delivery takes 5-7 business days.' },
                { q: 'Can I cancel my order?', a: 'Yes, you can cancel pending orders from the Track Order section.' },
                { q: 'Do you offer returns?', a: 'Yes, we offer 7-day hassle-free returns.' }
              ].map((faq, i) => (
                <details key={i} className="border rounded-lg p-3 cursor-pointer">
                  <summary className="font-medium">{faq.q}</summary>
                  <p className="text-gray-600 text-sm mt-2">{faq.a}</p>
                </details>
              ))}
            </div>
          </div>
        </div>

        {/* AI Chatbot */}
        <div className="bg-white rounded-xl shadow flex flex-col h-[600px]">
          <div className="p-4 bg-black text-white rounded-t-xl">
            <h2 className="font-bold">🤖 PARRLX AI Assistant</h2>
            <p className="text-xs text-gray-400">Ask anything about orders, delivery, returns...</p>
          </div>
          <div className="flex-1 overflow-y-auto p-4 space-y-3">
            {messages.map((msg, i) => (
              <div key={i} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                <div className={`max-w-[80%] px-4 py-2 rounded-2xl text-sm ${
                  msg.role === 'user' ? 'bg-black text-white rounded-br-sm' : 'bg-gray-100 text-gray-800 rounded-bl-sm'
                }`}>
                  {msg.text}
                </div>
              </div>
            ))}
          </div>
          <div className="p-3 border-t flex gap-2">
            <input value={input} onChange={e => setInput(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && handleSend()}
              placeholder="Type your question..."
              className="flex-1 border rounded-full px-4 py-2 text-sm focus:ring-2 focus:ring-yellow-500 focus:outline-none" />
            <button onClick={handleSend} className="bg-black text-white px-4 py-2 rounded-full text-sm font-bold hover:bg-gray-800">Send</button>
          </div>
        </div>
      </div>
    </div>
  );
}
