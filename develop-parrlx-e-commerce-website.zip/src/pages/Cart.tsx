import { Link, useNavigate } from 'react-router-dom';
import { useStore } from '../store';

export default function Cart() {
  const { cart, removeFromCart, updateCartQuantity, currentUser } = useStore();
  const navigate = useNavigate();

  const total = cart.reduce((sum, item) => sum + item.product.price * item.quantity, 0);

  const handleCheckout = () => {
    if (!currentUser) {
      navigate('/login');
      return;
    }
    navigate('/checkout');
  };

  if (cart.length === 0) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-16 text-center">
        <div className="text-6xl mb-4">🛒</div>
        <h2 className="text-2xl font-bold mb-2">Your cart is empty</h2>
        <p className="text-gray-500 mb-6">Browse our collection and add items to your cart</p>
        <Link to="/store" className="bg-black text-white px-8 py-3 rounded-lg font-bold hover:bg-gray-800">Shop Now</Link>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-6">Shopping Cart ({cart.length} items)</h1>

      <div className="space-y-4">
        {cart.map((item, index) => (
          <div key={index} className="bg-white rounded-xl shadow p-4 flex flex-col sm:flex-row gap-4">
            <div className="w-24 h-24 bg-gray-100 rounded-lg overflow-hidden flex-shrink-0">
              <img src={item.product.image} alt={item.product.name} className="w-full h-full object-cover" />
            </div>
            <div className="flex-1">
              <h3 className="font-bold text-lg">{item.product.name}</h3>
              <p className="text-sm text-gray-500">Size: {item.size} | Color: {item.color}</p>
              <p className="text-green-600 font-bold text-lg mt-1">₹{item.product.price}</p>
            </div>
            <div className="flex items-center gap-3">
              <div className="flex items-center gap-2">
                <button onClick={() => updateCartQuantity(index, Math.max(1, item.quantity - 1))}
                  className="w-8 h-8 border rounded flex items-center justify-center hover:bg-gray-100">-</button>
                <span className="w-8 text-center font-bold">{item.quantity}</span>
                <button onClick={() => updateCartQuantity(index, item.quantity + 1)}
                  className="w-8 h-8 border rounded flex items-center justify-center hover:bg-gray-100">+</button>
              </div>
              <p className="font-bold min-w-[80px] text-right">₹{item.product.price * item.quantity}</p>
              <button onClick={() => removeFromCart(index)} className="text-red-500 hover:text-red-700 text-xl">✕</button>
            </div>
          </div>
        ))}
      </div>

      <div className="bg-white rounded-xl shadow p-6 mt-6">
        <div className="flex justify-between items-center text-xl font-bold">
          <span>Total</span>
          <span className="text-green-600">₹{total}</span>
        </div>
        <button onClick={handleCheckout}
          className="w-full mt-4 bg-yellow-500 text-black py-3 rounded-lg font-bold text-lg hover:bg-yellow-400 transition">
          Proceed to Checkout
        </button>
        <Link to="/store" className="block text-center mt-3 text-gray-500 hover:text-black">← Continue Shopping</Link>
      </div>
    </div>
  );
}
