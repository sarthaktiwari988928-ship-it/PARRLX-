import { Link, useNavigate } from 'react-router-dom';
import { useStore } from '../store';

export default function AdminDashboard() {
  const { currentUser, getAllOrders, products, users, members } = useStore();
  const navigate = useNavigate();

  if (!currentUser || (currentUser.role !== 'admin' && currentUser.role !== 'member')) {
    navigate('/login');
    return null;
  }

  const isAdmin = currentUser.role === 'admin';
  const orders = getAllOrders();
  const totalOrders = orders.length;
  const totalSales = orders.filter(o => o.status !== 'cancelled').reduce((sum, o) => sum + o.total, 0);
  const pendingOrders = orders.filter(o => o.status === 'pending').length;
  const shippedOrders = orders.filter(o => o.status === 'shipped').length;
  const deliveredOrders = orders.filter(o => o.status === 'delivered').length;
  const cancelledOrders = orders.filter(o => o.status === 'cancelled').length;
  const totalProfit = Math.round(totalSales * 0.3); // 30% margin estimate

  return (
    <div className="max-w-6xl mx-auto px-4 py-8">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-3xl font-bold">
            {isAdmin ? '👑 Admin Dashboard' : '🏷️ Team Dashboard'}
          </h1>
          <p className="text-gray-500">Welcome, {currentUser.name}</p>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
        <div className="bg-white rounded-xl shadow p-5 text-center">
          <p className="text-3xl font-bold text-blue-600">{totalOrders}</p>
          <p className="text-sm text-gray-500 mt-1">Total Orders</p>
        </div>
        <div className="bg-white rounded-xl shadow p-5 text-center">
          <p className="text-3xl font-bold text-green-600">₹{totalSales.toLocaleString()}</p>
          <p className="text-sm text-gray-500 mt-1">Total Sales</p>
        </div>
        <div className="bg-white rounded-xl shadow p-5 text-center">
          <p className="text-3xl font-bold text-purple-600">₹{totalProfit.toLocaleString()}</p>
          <p className="text-sm text-gray-500 mt-1">Est. Profit</p>
        </div>
        <div className="bg-white rounded-xl shadow p-5 text-center">
          <p className="text-3xl font-bold text-orange-600">{products.length}</p>
          <p className="text-sm text-gray-500 mt-1">Products</p>
        </div>
      </div>

      {/* Order Status Summary */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
        <div className="bg-yellow-50 rounded-xl p-4 text-center border border-yellow-200">
          <p className="text-2xl font-bold text-yellow-600">{pendingOrders}</p>
          <p className="text-xs text-yellow-600">⏳ Pending</p>
        </div>
        <div className="bg-blue-50 rounded-xl p-4 text-center border border-blue-200">
          <p className="text-2xl font-bold text-blue-600">{shippedOrders}</p>
          <p className="text-xs text-blue-600">🚚 Shipped</p>
        </div>
        <div className="bg-green-50 rounded-xl p-4 text-center border border-green-200">
          <p className="text-2xl font-bold text-green-600">{deliveredOrders}</p>
          <p className="text-xs text-green-600">✅ Delivered</p>
        </div>
        <div className="bg-red-50 rounded-xl p-4 text-center border border-red-200">
          <p className="text-2xl font-bold text-red-600">{cancelledOrders}</p>
          <p className="text-xs text-red-600">❌ Cancelled</p>
        </div>
      </div>

      {/* Quick Actions */}
      <h2 className="text-xl font-bold mb-4">Quick Actions</h2>
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
        <Link to="/admin/products" className="bg-white rounded-xl shadow p-5 text-center hover:shadow-lg transition">
          <div className="text-3xl mb-2">👕</div>
          <p className="font-bold">Manage Products</p>
          <p className="text-xs text-gray-500">Add, edit, remove</p>
        </Link>
        <Link to="/admin/orders" className="bg-white rounded-xl shadow p-5 text-center hover:shadow-lg transition">
          <div className="text-3xl mb-2">📦</div>
          <p className="font-bold">Manage Orders</p>
          <p className="text-xs text-gray-500">View, ship, deliver</p>
        </Link>
        {isAdmin && (
          <>
            <Link to="/admin/redeem-codes" className="bg-white rounded-xl shadow p-5 text-center hover:shadow-lg transition">
              <div className="text-3xl mb-2">🎟️</div>
              <p className="font-bold">Redeem Codes</p>
              <p className="text-xs text-gray-500">Create discount codes</p>
            </Link>
            <Link to="/admin/offers" className="bg-white rounded-xl shadow p-5 text-center hover:shadow-lg transition">
              <div className="text-3xl mb-2">🔥</div>
              <p className="font-bold">Offers & Sales</p>
              <p className="text-xs text-gray-500">Create offers</p>
            </Link>
            <Link to="/admin/members" className="bg-white rounded-xl shadow p-5 text-center hover:shadow-lg transition">
              <div className="text-3xl mb-2">👥</div>
              <p className="font-bold">Team Members</p>
              <p className="text-xs text-gray-500">Add team members</p>
            </Link>
            <Link to="/admin/users" className="bg-white rounded-xl shadow p-5 text-center hover:shadow-lg transition">
              <div className="text-3xl mb-2">👤</div>
              <p className="font-bold">User Accounts</p>
              <p className="text-xs text-gray-500">View all users</p>
            </Link>
            <Link to="/admin/analytics" className="bg-white rounded-xl shadow p-5 text-center hover:shadow-lg transition">
              <div className="text-3xl mb-2">📊</div>
              <p className="font-bold">Analytics</p>
              <p className="text-xs text-gray-500">Website insights</p>
            </Link>
          </>
        )}
        <Link to="/store" className="bg-white rounded-xl shadow p-5 text-center hover:shadow-lg transition">
          <div className="text-3xl mb-2">🏪</div>
          <p className="font-bold">View Store</p>
          <p className="text-xs text-gray-500">See customer view</p>
        </Link>
      </div>

      {/* Recent Orders */}
      <h2 className="text-xl font-bold mt-10 mb-4">Recent Orders</h2>
      {orders.length === 0 ? (
        <p className="text-gray-500">No orders yet</p>
      ) : (
        <div className="bg-white rounded-xl shadow overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-gray-50">
              <tr>
                <th className="text-left p-3">Order ID</th>
                <th className="text-left p-3">Customer</th>
                <th className="text-left p-3">Total</th>
                <th className="text-left p-3">Status</th>
                <th className="text-left p-3">Date</th>
              </tr>
            </thead>
            <tbody>
              {orders.slice(0, 10).map(order => {
                const customer = users.find(u => u.id === order.userId);
                return (
                  <tr key={order.id} className="border-t hover:bg-gray-50">
                    <td className="p-3 font-mono text-xs">{order.id}</td>
                    <td className="p-3">{customer?.name || order.shippingDetails.fullName}</td>
                    <td className="p-3 font-bold text-green-600">₹{order.total}</td>
                    <td className="p-3">
                      <span className={`px-2 py-0.5 rounded-full text-xs font-bold ${
                        order.status === 'pending' ? 'bg-yellow-100 text-yellow-700' :
                        order.status === 'shipped' ? 'bg-blue-100 text-blue-700' :
                        order.status === 'delivered' ? 'bg-green-100 text-green-700' :
                        'bg-red-100 text-red-700'
                      }`}>{order.status}</span>
                    </td>
                    <td className="p-3 text-gray-500">{new Date(order.date).toLocaleDateString()}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}

      {isAdmin && (
        <p className="text-xs text-gray-400 mt-4">Team Members: {members.length} | Total Users: {users.filter(u => u.role === 'customer').length}</p>
      )}
    </div>
  );
}
