import { useNavigate } from 'react-router-dom';
import { useStore } from '../store';

export default function TrackOrder() {
  const { currentUser, getUserOrders, cancelOrder } = useStore();
  const navigate = useNavigate();

  if (!currentUser) { navigate('/login'); return null; }

  const orders = getUserOrders(currentUser.id);
  const activeOrders = orders.filter(o => o.status !== 'delivered' && o.status !== 'cancelled');

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending': return 'bg-yellow-100 text-yellow-700';
      case 'shipped': return 'bg-blue-100 text-blue-700';
      case 'delivered': return 'bg-green-100 text-green-700';
      case 'cancelled': return 'bg-red-100 text-red-700';
      default: return 'bg-gray-100 text-gray-700';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'pending': return '⏳';
      case 'shipped': return '🚚';
      case 'delivered': return '✅';
      case 'cancelled': return '❌';
      default: return '📦';
    }
  };

  const handleCancel = (orderId: string) => {
    if (confirm('Are you sure you want to cancel this order?')) {
      cancelOrder(orderId);
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-6">Track Your Orders</h1>

      {activeOrders.length === 0 ? (
        <div className="text-center py-16">
          <div className="text-5xl mb-4">📦</div>
          <h2 className="text-xl font-bold mb-2">No active orders</h2>
          <p className="text-gray-500">You don't have any active orders right now</p>
        </div>
      ) : (
        <div className="space-y-4">
          {activeOrders.map(order => (
            <div key={order.id} className="bg-white rounded-xl shadow-md p-5 space-y-3">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div>
                  <p className="font-bold text-lg">{order.id}</p>
                  <p className="text-sm text-gray-500">{new Date(order.date).toLocaleString()}</p>
                </div>
                <span className={`px-3 py-1 rounded-full text-sm font-bold ${getStatusColor(order.status)}`}>
                  {getStatusIcon(order.status)} {order.status.toUpperCase()}
                </span>
              </div>

              {/* Progress bar */}
              <div className="flex items-center gap-1">
                <div className={`h-2 flex-1 rounded-full ${order.status !== 'cancelled' ? 'bg-green-500' : 'bg-red-500'}`}></div>
                <div className={`h-2 flex-1 rounded-full ${order.status === 'shipped' || order.status === 'delivered' ? 'bg-green-500' : 'bg-gray-200'}`}></div>
                <div className={`h-2 flex-1 rounded-full ${order.status === 'delivered' ? 'bg-green-500' : 'bg-gray-200'}`}></div>
              </div>
              <div className="flex justify-between text-xs text-gray-500">
                <span>Order Placed</span>
                <span>Shipped</span>
                <span>Delivered</span>
              </div>

              <div className="border-t pt-3 space-y-2">
                {order.items.map((item, i) => (
                  <div key={i} className="flex gap-3 items-center">
                    <div className="w-12 h-12 bg-gray-100 rounded overflow-hidden flex-shrink-0">
                      <img src={item.product.image} alt="" className="w-full h-full object-cover" />
                    </div>
                    <div className="flex-1">
                      <p className="font-medium text-sm">{item.product.name}</p>
                      <p className="text-xs text-gray-500">{item.size} | {item.color} × {item.quantity}</p>
                    </div>
                    <p className="font-bold text-sm">₹{item.product.price * item.quantity}</p>
                  </div>
                ))}
              </div>

              <div className="flex justify-between items-center border-t pt-3">
                <div>
                  <p className="text-sm text-gray-500">Payment: {order.paymentMethod === 'cod' ? 'Cash on Delivery' : 'Online'}</p>
                  <p className="font-bold text-lg text-green-600">Total: ₹{order.total}</p>
                </div>
                {order.status === 'pending' && (
                  <button onClick={() => handleCancel(order.id)}
                    className="bg-red-600 text-white px-4 py-2 rounded-lg text-sm font-bold hover:bg-red-700">
                    Cancel Order
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
