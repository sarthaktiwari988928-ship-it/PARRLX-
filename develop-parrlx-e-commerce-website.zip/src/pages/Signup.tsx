import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useStore } from '../store';
import { User } from '../types';

export default function Signup() {
  const { signup } = useStore();
  const navigate = useNavigate();
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    if (password !== confirmPassword) {
      setError('Passwords do not match');
      return;
    }
    if (password.length < 6) {
      setError('Password must be at least 6 characters');
      return;
    }

    const user: User = {
      id: 'user-' + Date.now().toString(36),
      name,
      email,
      password,
      phone,
      role: 'customer',
      createdAt: new Date().toISOString()
    };

    const success = signup(user);
    if (success) {
      navigate('/');
    } else {
      setError('An account with this email already exists');
    }
  };

  return (
    <div className="min-h-[70vh] flex items-center justify-center px-4 py-8">
      <div className="bg-white rounded-2xl shadow-xl p-8 w-full max-w-md">
        <div className="text-center mb-6">
          <img src="https://i.ibb.co/BHbBt9vB/IMG-.jpg" alt="PARRLX" className="h-16 w-16 rounded-full mx-auto mb-3 border-2 border-black" />
          <h1 className="text-2xl font-black tracking-widest">PARRLX</h1>
          <p className="text-gray-500 text-sm mt-1">Create your account</p>
        </div>

        {error && <div className="bg-red-50 text-red-600 px-4 py-2 rounded-lg mb-4 text-sm">{error}</div>}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="text-sm font-medium text-gray-600">Full Name</label>
            <input type="text" value={name} onChange={e => setName(e.target.value)} required
              className="w-full border rounded-lg px-4 py-2.5 mt-1 focus:ring-2 focus:ring-yellow-500 focus:outline-none" placeholder="Enter your name" />
          </div>
          <div>
            <label className="text-sm font-medium text-gray-600">Email</label>
            <input type="email" value={email} onChange={e => setEmail(e.target.value)} required
              className="w-full border rounded-lg px-4 py-2.5 mt-1 focus:ring-2 focus:ring-yellow-500 focus:outline-none" placeholder="Enter your email" />
          </div>
          <div>
            <label className="text-sm font-medium text-gray-600">Phone</label>
            <input type="tel" value={phone} onChange={e => setPhone(e.target.value)} required
              className="w-full border rounded-lg px-4 py-2.5 mt-1 focus:ring-2 focus:ring-yellow-500 focus:outline-none" placeholder="Enter your phone number" />
          </div>
          <div>
            <label className="text-sm font-medium text-gray-600">Password</label>
            <div className="relative">
              <input type={showPassword ? 'text' : 'password'} value={password} onChange={e => setPassword(e.target.value)} required
                className="w-full border rounded-lg px-4 py-2.5 mt-1 pr-16 focus:ring-2 focus:ring-yellow-500 focus:outline-none" placeholder="Create a password" />
              <button type="button" onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-1/2 -translate-y-1/2 mt-0.5 text-sm text-gray-500 hover:text-black">
                {showPassword ? '🙈 Hide' : '👁️ Show'}
              </button>
            </div>
          </div>
          <div>
            <label className="text-sm font-medium text-gray-600">Confirm Password</label>
            <input type={showPassword ? 'text' : 'password'} value={confirmPassword} onChange={e => setConfirmPassword(e.target.value)} required
              className="w-full border rounded-lg px-4 py-2.5 mt-1 focus:ring-2 focus:ring-yellow-500 focus:outline-none" placeholder="Confirm your password" />
          </div>
          <button type="submit" className="w-full bg-black text-white py-3 rounded-lg font-bold hover:bg-gray-800 transition">
            Create Account
          </button>
        </form>

        <p className="text-center mt-4 text-sm text-gray-500">
          Already have an account? <Link to="/login" className="text-yellow-600 font-bold hover:underline">Login</Link>
        </p>
      </div>
    </div>
  );
}
