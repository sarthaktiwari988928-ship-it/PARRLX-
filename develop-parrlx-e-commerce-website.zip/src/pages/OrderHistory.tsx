import { useNavigate } from 'react-router-dom';
import { useStore } from '../store';

export default function OrderHistory() {
  const { currentUser, getUserOrders } = useStore();
  const navigate = useNavigate();

  if (!currentUser) { navigate('/login'); return null; }

  const orders = getUserOrders(currentUser.id);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending': return 'bg-yellow-100 text-yellow-700';
      case 'shipped': return 'bg-blue-100 text-blue-700';
      case 'delivered': return 'bg-green-100 text-green-700';
      case 'cancelled': return 'bg-red-100 text-red-700';
      default: return 'bg-gray-100 text-gray-700';
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-6">Order History</h1>

      {orders.length === 0 ? (
        <div className="text-center py-16">
          <div className="text-5xl mb-4">📋</div>
          <h2 className="text-xl font-bold mb-2">No orders yet</h2>
          <p className="text-gray-500">Your order history will appear here</p>
        </div>
      ) : (
        <div className="space-y-4">
          {orders.map(order => (
            <div key={order.id} className="bg-white rounded-xl shadow p-5">
              <div className="flex flex-wrap items-center justify-between gap-2 mb-3">
                <div>
                  <p className="font-bold">{order.id}</p>
                  <p className="text-xs text-gray-500">{new Date(order.date).toLocaleString()}</p>
                </div>
                <span className={`px-3 py-1 rounded-full text-xs font-bold ${getStatusColor(order.status)}`}>
                  {order.status.toUpperCase()}
                </span>
              </div>
              <div className="space-y-2 border-t pt-3">
                {order.items.map((item, i) => (
                  <div key={i} className="flex gap-3 items-center">
                    <div className="w-10 h-10 bg-gray-100 rounded overflow-hidden flex-shrink-0">
                      <img src={item.product.image} alt="" className="w-full h-full object-cover" />
                    </div>
                    <div className="flex-1">
                      <p className="font-medium text-sm">{item.product.name}</p>
                      <p className="text-xs text-gray-500">{item.size} | {item.color} × {item.quantity}</p>
                    </div>
                    <p className="font-bold text-sm">₹{item.product.price * item.quantity}</p>
                  </div>
                ))}
              </div>
              <div className="flex justify-between items-center border-t pt-3 mt-3">
                <p className="text-sm text-gray-500">{order.paymentMethod === 'cod' ? 'Cash on Delivery' : 'Online Payment'}</p>
                <p className="font-bold text-green-600">₹{order.total}</p>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
