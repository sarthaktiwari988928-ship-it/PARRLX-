import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useStore } from '../store';
import { User } from '../types';

export default function AdminMembers() {
  const { currentUser, members, addMember, removeMember } = useStore();
  const navigate = useNavigate();
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [phone, setPhone] = useState('');

  if (!currentUser || currentUser.role !== 'admin') {
    navigate('/login'); return null;
  }

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !email || !password) return;

    const member: User = {
      id: 'member-' + Date.now().toString(36),
      name,
      email,
      password,
      phone,
      role: 'member',
      createdAt: new Date().toISOString()
    };

    addMember(member);
    setName(''); setEmail(''); setPassword(''); setPhone('');
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-6">👥 Team Members</h1>
      <p className="text-gray-500 mb-6">Team members can add/remove products and manage orders, but cannot access admin-only features like redeem codes, offers, analytics, or user management.</p>

      <div className="bg-white rounded-xl shadow-lg p-6 mb-8">
        <h2 className="text-xl font-bold mb-4">Add Team Member</h2>
        <form onSubmit={handleAdd} className="grid md:grid-cols-2 gap-3">
          <input value={name} onChange={e => setName(e.target.value)} placeholder="Full Name"
            className="border rounded-lg px-4 py-2 focus:ring-2 focus:ring-yellow-500 focus:outline-none" required />
          <input type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="Email"
            className="border rounded-lg px-4 py-2 focus:ring-2 focus:ring-yellow-500 focus:outline-none" required />
          <input value={phone} onChange={e => setPhone(e.target.value)} placeholder="Phone"
            className="border rounded-lg px-4 py-2 focus:ring-2 focus:ring-yellow-500 focus:outline-none" />
          <input value={password} onChange={e => setPassword(e.target.value)} placeholder="Password"
            className="border rounded-lg px-4 py-2 focus:ring-2 focus:ring-yellow-500 focus:outline-none" required />
          <div className="md:col-span-2">
            <button type="submit" className="bg-black text-white px-6 py-2 rounded-lg font-bold hover:bg-gray-800">Add Member</button>
          </div>
        </form>
      </div>

      {members.length === 0 ? (
        <p className="text-gray-500 text-center py-8">No team members added yet</p>
      ) : (
        <div className="space-y-3">
          {members.map(member => (
            <div key={member.id} className="bg-white rounded-xl shadow p-4 flex items-center justify-between">
              <div>
                <p className="font-bold">{member.name}</p>
                <p className="text-sm text-gray-500">{member.email} {member.phone && `| ${member.phone}`}</p>
                <p className="text-xs text-gray-400">Joined {new Date(member.createdAt).toLocaleDateString()}</p>
              </div>
              <div className="flex gap-2 items-center">
                <span className="px-2 py-0.5 rounded-full text-xs font-bold bg-blue-100 text-blue-700">Member</span>
                <button onClick={() => removeMember(member.id)} className="bg-red-600 text-white px-3 py-1.5 rounded-lg text-sm font-bold hover:bg-red-700">Remove</button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
