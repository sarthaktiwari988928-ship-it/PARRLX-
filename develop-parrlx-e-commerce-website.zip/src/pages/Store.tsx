import { Link, useNavigate } from 'react-router-dom';
import { useStore } from '../store';
import { useState } from 'react';

export default function Store() {
  const { products, addToCart, currentUser } = useStore();
  const navigate = useNavigate();
  const [filter, setFilter] = useState('All');
  const [search, setSearch] = useState('');

  const categories = ['All', ...Array.from(new Set(products.map(p => p.category)))];
  const filtered = products.filter(p => {
    const matchCat = filter === 'All' || p.category === filter;
    const matchSearch = p.name.toLowerCase().includes(search.toLowerCase());
    return matchCat && matchSearch;
  });

  const handleAddToCart = (product: typeof products[0]) => {
    if (!currentUser) {
      navigate('/login');
      return;
    }
    addToCart({ product, quantity: 1, size: product.sizes[0] || 'M', color: product.colors[0] || 'Black' });
  };

  const handleBuyNow = (product: typeof products[0]) => {
    if (!currentUser) {
      navigate('/login');
      return;
    }
    addToCart({ product, quantity: 1, size: product.sizes[0] || 'M', color: product.colors[0] || 'Black' });
    navigate('/checkout');
  };

  const handleShare = (product: typeof products[0]) => {
    const url = window.location.origin + `/#/product/${product.id}`;
    if (navigator.share) {
      navigator.share({ title: product.name, text: `Check out ${product.name} on PARRLX!`, url });
    } else {
      navigator.clipboard.writeText(url);
      alert('Product link copied to clipboard!');
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-6 text-center">Our Collection</h1>

      {/* Search and Filter */}
      <div className="flex flex-col sm:flex-row gap-4 mb-8">
        <input
          type="text"
          placeholder="Search products..."
          value={search}
          onChange={e => setSearch(e.target.value)}
          className="flex-1 border border-gray-300 rounded-lg px-4 py-2 focus:ring-2 focus:ring-yellow-500 focus:outline-none"
        />
        <select value={filter} onChange={e => setFilter(e.target.value)} className="border border-gray-300 rounded-lg px-4 py-2 focus:ring-2 focus:ring-yellow-500 focus:outline-none">
          {categories.map(c => <option key={c} value={c}>{c}</option>)}
        </select>
      </div>

      {filtered.length === 0 && (
        <div className="text-center py-16">
          <div className="text-5xl mb-4">🏷️</div>
          <p className="text-gray-500 text-lg">No products available yet. Check back soon!</p>
        </div>
      )}

      {/* Products List - Vertical */}
      <div className="flex flex-col gap-6">
        {filtered.map(product => (
          <div key={product.id} className="bg-white rounded-xl shadow-md hover:shadow-xl transition overflow-hidden flex flex-col sm:flex-row">
            <Link to={`/product/${product.id}`} className="sm:w-56 h-56 sm:h-auto bg-gray-100 flex-shrink-0 block">
              <img src={product.image} alt={product.name} className="w-full h-full object-cover" />
            </Link>
            <div className="p-5 flex-1 flex flex-col justify-between">
              <div>
                <Link to={`/product/${product.id}`}>
                  <h3 className="font-bold text-xl hover:text-yellow-600 transition">{product.name}</h3>
                </Link>
                <p className="text-gray-500 text-sm mt-1">{product.category}</p>
                <p className="text-gray-600 text-sm mt-2 line-clamp-2">{product.description}</p>
                <div className="flex items-center gap-2 mt-2">
                  <span className="text-2xl font-bold text-green-600">₹{product.price}</span>
                  {product.originalPrice && product.originalPrice > product.price && (
                    <>
                      <span className="text-sm text-gray-400 line-through">₹{product.originalPrice}</span>
                      <span className="text-xs bg-red-100 text-red-600 px-2 py-0.5 rounded-full font-bold">
                        {Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100)}% OFF
                      </span>
                    </>
                  )}
                </div>
                <div className="flex items-center gap-1 mt-1">
                  {'⭐'.repeat(Math.round(product.rating))}
                  <span className="text-xs text-gray-400">({product.reviewCount} reviews)</span>
                </div>
              </div>
              <div className="flex gap-3 mt-4 flex-wrap">
                <button onClick={() => handleAddToCart(product)} className="bg-black text-white px-5 py-2 rounded-lg font-bold text-sm hover:bg-gray-800 transition">
                  🛒 Add to Cart
                </button>
                <button onClick={() => handleBuyNow(product)} className="bg-yellow-500 text-black px-5 py-2 rounded-lg font-bold text-sm hover:bg-yellow-400 transition">
                  ⚡ Buy Now
                </button>
                <button onClick={() => handleShare(product)} className="border border-gray-300 px-4 py-2 rounded-lg text-sm hover:bg-gray-100 transition">
                  📤 Share
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
