import { Link } from 'react-router-dom';
import { useStore } from '../store';

export default function Home() {
  const { offers, products } = useStore();
  const activeOffers = offers.filter(o => o.active);

  return (
    <div>
      {/* Hero Section */}
      <div className="relative bg-black text-white overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-black via-gray-900 to-black opacity-90"></div>
        <div className="relative max-w-7xl mx-auto px-4 py-24 md:py-36 text-center">
          <img src="https://i.ibb.co/BHbBt9vB/IMG-.jpg" alt="PARRLX" className="h-24 w-24 rounded-full mx-auto mb-6 border-4 border-yellow-500 shadow-2xl" />
          <h1 className="text-5xl md:text-7xl font-black tracking-[0.3em] mb-4">PARRLX</h1>
          <p className="text-xl md:text-2xl text-gray-300 mb-2">Premium Clothing Brand</p>
          <p className="text-gray-400 mb-8 max-w-xl mx-auto">Quality. Style. Confidence. — Discover the latest trends in fashion with PARRLX premium collection.</p>
          <div className="flex gap-4 justify-center flex-wrap">
            <Link to="/store" className="bg-yellow-500 text-black px-8 py-3 rounded-lg font-bold text-lg hover:bg-yellow-400 transition shadow-lg">
              Shop Now
            </Link>
            <Link to="/store" className="border-2 border-white px-8 py-3 rounded-lg font-bold text-lg hover:bg-white hover:text-black transition">
              Explore Collection
            </Link>
          </div>
        </div>
      </div>

      {/* Active Offers */}
      {activeOffers.length > 0 && (
        <div className="bg-yellow-500 py-3">
          <div className="max-w-7xl mx-auto px-4">
            <div className="flex overflow-x-auto gap-6 items-center justify-center">
              {activeOffers.map(offer => (
                <div key={offer.id} className="text-center whitespace-nowrap">
                  <span className="font-bold text-black">🔥 {offer.title}</span>
                  <span className="text-black/80 ml-2 text-sm">{offer.description}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Featured Products */}
      {products.length > 0 && (
        <section className="max-w-7xl mx-auto px-4 py-16">
          <h2 className="text-3xl font-bold text-center mb-10">Featured Products</h2>
          <div className="flex flex-col gap-6 max-w-2xl mx-auto">
            {products.slice(0, 4).map(product => (
              <Link key={product.id} to={`/product/${product.id}`} className="bg-white rounded-xl shadow-md hover:shadow-xl transition overflow-hidden flex flex-col sm:flex-row">
                <div className="sm:w-48 h-48 sm:h-auto bg-gray-100 flex-shrink-0">
                  <img src={product.image} alt={product.name} className="w-full h-full object-cover" />
                </div>
                <div className="p-4 flex-1 flex flex-col justify-center">
                  <h3 className="font-bold text-lg">{product.name}</h3>
                  <p className="text-gray-500 text-sm">{product.category}</p>
                  <div className="flex items-center gap-2 mt-2">
                    <span className="text-xl font-bold text-green-600">₹{product.price}</span>
                    {product.originalPrice && product.originalPrice > product.price && (
                      <span className="text-sm text-gray-400 line-through">₹{product.originalPrice}</span>
                    )}
                  </div>
                  <div className="flex items-center gap-1 mt-1">
                    {'⭐'.repeat(Math.round(product.rating))}
                    <span className="text-xs text-gray-400">({product.reviewCount})</span>
                  </div>
                </div>
              </Link>
            ))}
          </div>
          {products.length > 4 && (
            <div className="text-center mt-8">
              <Link to="/store" className="bg-black text-white px-8 py-3 rounded-lg font-bold hover:bg-gray-800 transition">View All Products</Link>
            </div>
          )}
        </section>
      )}

      {products.length === 0 && (
        <section className="max-w-7xl mx-auto px-4 py-24 text-center">
          <div className="text-6xl mb-4">👕</div>
          <h2 className="text-2xl font-bold mb-2">Coming Soon</h2>
          <p className="text-gray-500">Our exclusive collection is being curated. Stay tuned!</p>
        </section>
      )}

      {/* Brand Features */}
      <section className="bg-black text-white py-16">
        <div className="max-w-7xl mx-auto px-4 grid md:grid-cols-3 gap-8 text-center">
          <div className="space-y-3">
            <div className="text-4xl">🚚</div>
            <h3 className="text-xl font-bold">Free Shipping</h3>
            <p className="text-gray-400">On all orders above ₹999</p>
          </div>
          <div className="space-y-3">
            <div className="text-4xl">💳</div>
            <h3 className="text-xl font-bold">Secure Payment</h3>
            <p className="text-gray-400">Online & Cash on Delivery</p>
          </div>
          <div className="space-y-3">
            <div className="text-4xl">🔄</div>
            <h3 className="text-xl font-bold">Easy Returns</h3>
            <p className="text-gray-400">7-day hassle-free returns</p>
          </div>
        </div>
      </section>
    </div>
  );
}
