import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useStore } from '../store';
import { Product } from '../types';

export default function AdminProducts() {
  const { currentUser, products, addProduct, updateProduct, removeProduct } = useStore();
  const navigate = useNavigate();

  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState<Product | null>(null);
  const [form, setForm] = useState({
    name: '', price: '', originalPrice: '', image: '', category: '', description: '',
    sizes: '', colors: '', inStock: true
  });

  if (!currentUser || (currentUser.role !== 'admin' && currentUser.role !== 'member')) {
    navigate('/login'); return null;
  }

  const resetForm = () => {
    setForm({ name: '', price: '', originalPrice: '', image: '', category: '', description: '', sizes: '', colors: '', inStock: true });
    setEditing(null);
    setShowForm(false);
  };

  const handleEdit = (p: Product) => {
    setForm({
      name: p.name, price: p.price.toString(), originalPrice: (p.originalPrice || '').toString(),
      image: p.image, category: p.category, description: p.description,
      sizes: p.sizes.join(', '), colors: p.colors.join(', '), inStock: p.inStock
    });
    setEditing(p);
    setShowForm(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name || !form.price || !form.image || !form.category) {
      alert('Please fill all required fields');
      return;
    }

    const productData: Product = {
      id: editing?.id || 'prod-' + Date.now().toString(36),
      name: form.name,
      price: Number(form.price),
      originalPrice: form.originalPrice ? Number(form.originalPrice) : undefined,
      image: form.image,
      category: form.category,
      description: form.description,
      sizes: form.sizes.split(',').map(s => s.trim()).filter(Boolean),
      colors: form.colors.split(',').map(c => c.trim()).filter(Boolean),
      rating: editing?.rating || 0,
      reviewCount: editing?.reviewCount || 0,
      inStock: form.inStock
    };

    if (editing) {
      updateProduct(productData);
    } else {
      addProduct(productData);
    }
    resetForm();
  };

  const handleRemove = (id: string) => {
    if (confirm('Are you sure you want to remove this product?')) {
      removeProduct(id);
    }
  };

  return (
    <div className="max-w-6xl mx-auto px-4 py-8">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-3xl font-bold">Manage Products</h1>
        <button onClick={() => { resetForm(); setShowForm(true); }}
          className="bg-black text-white px-6 py-2 rounded-lg font-bold hover:bg-gray-800">+ Add Product</button>
      </div>

      {/* Add/Edit Form */}
      {showForm && (
        <div className="bg-white rounded-xl shadow-lg p-6 mb-8">
          <h2 className="text-xl font-bold mb-4">{editing ? 'Edit Product' : 'Add New Product'}</h2>
          <form onSubmit={handleSubmit} className="grid md:grid-cols-2 gap-4">
            <div>
              <label className="text-sm font-medium">Product Name *</label>
              <input value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))}
                className="w-full border rounded-lg px-3 py-2 mt-1 focus:ring-2 focus:ring-yellow-500 focus:outline-none" required />
            </div>
            <div>
              <label className="text-sm font-medium">Category *</label>
              <input value={form.category} onChange={e => setForm(f => ({ ...f, category: e.target.value }))}
                className="w-full border rounded-lg px-3 py-2 mt-1 focus:ring-2 focus:ring-yellow-500 focus:outline-none" placeholder="e.g. T-Shirts, Jeans" required />
            </div>
            <div>
              <label className="text-sm font-medium">Price (₹) *</label>
              <input type="number" value={form.price} onChange={e => setForm(f => ({ ...f, price: e.target.value }))}
                className="w-full border rounded-lg px-3 py-2 mt-1 focus:ring-2 focus:ring-yellow-500 focus:outline-none" required />
            </div>
            <div>
              <label className="text-sm font-medium">Original Price (₹) <span className="text-gray-400">(for discount)</span></label>
              <input type="number" value={form.originalPrice} onChange={e => setForm(f => ({ ...f, originalPrice: e.target.value }))}
                className="w-full border rounded-lg px-3 py-2 mt-1 focus:ring-2 focus:ring-yellow-500 focus:outline-none" />
            </div>
            <div className="md:col-span-2">
              <label className="text-sm font-medium">Image URL *</label>
              <input value={form.image} onChange={e => setForm(f => ({ ...f, image: e.target.value }))}
                className="w-full border rounded-lg px-3 py-2 mt-1 focus:ring-2 focus:ring-yellow-500 focus:outline-none" placeholder="https://..." required />
              {form.image && <img src={form.image} alt="preview" className="mt-2 h-20 rounded" />}
            </div>
            <div className="md:col-span-2">
              <label className="text-sm font-medium">Description</label>
              <textarea value={form.description} onChange={e => setForm(f => ({ ...f, description: e.target.value }))}
                className="w-full border rounded-lg px-3 py-2 mt-1 focus:ring-2 focus:ring-yellow-500 focus:outline-none" rows={3} />
            </div>
            <div>
              <label className="text-sm font-medium">Sizes <span className="text-gray-400">(comma separated)</span></label>
              <input value={form.sizes} onChange={e => setForm(f => ({ ...f, sizes: e.target.value }))}
                className="w-full border rounded-lg px-3 py-2 mt-1 focus:ring-2 focus:ring-yellow-500 focus:outline-none" placeholder="S, M, L, XL" />
            </div>
            <div>
              <label className="text-sm font-medium">Colors <span className="text-gray-400">(comma separated)</span></label>
              <input value={form.colors} onChange={e => setForm(f => ({ ...f, colors: e.target.value }))}
                className="w-full border rounded-lg px-3 py-2 mt-1 focus:ring-2 focus:ring-yellow-500 focus:outline-none" placeholder="Black, White, Red" />
            </div>
            <div className="flex items-center gap-2">
              <input type="checkbox" checked={form.inStock} onChange={e => setForm(f => ({ ...f, inStock: e.target.checked }))} className="accent-yellow-500" />
              <label className="text-sm font-medium">In Stock</label>
            </div>
            <div className="md:col-span-2 flex gap-3">
              <button type="submit" className="bg-yellow-500 text-black px-6 py-2 rounded-lg font-bold hover:bg-yellow-400">
                {editing ? 'Update Product' : 'Add Product'}
              </button>
              <button type="button" onClick={resetForm} className="border px-6 py-2 rounded-lg hover:bg-gray-100">Cancel</button>
            </div>
          </form>
        </div>
      )}

      {/* Product List */}
      {products.length === 0 ? (
        <div className="text-center py-16">
          <div className="text-5xl mb-4">📦</div>
          <p className="text-gray-500 text-lg">No products yet. Click "Add Product" to get started.</p>
        </div>
      ) : (
        <div className="space-y-4">
          {products.map(product => (
            <div key={product.id} className="bg-white rounded-xl shadow p-4 flex flex-col sm:flex-row gap-4">
              <div className="w-20 h-20 bg-gray-100 rounded-lg overflow-hidden flex-shrink-0">
                <img src={product.image} alt="" className="w-full h-full object-cover" />
              </div>
              <div className="flex-1">
                <h3 className="font-bold">{product.name}</h3>
                <p className="text-sm text-gray-500">{product.category}</p>
                <div className="flex items-center gap-2 mt-1">
                  <span className="font-bold text-green-600">₹{product.price}</span>
                  {product.originalPrice && <span className="text-xs text-gray-400 line-through">₹{product.originalPrice}</span>}
                  {!product.inStock && <span className="text-xs bg-red-100 text-red-600 px-2 py-0.5 rounded-full">Out of Stock</span>}
                </div>
              </div>
              <div className="flex gap-2 items-start">
                <button onClick={() => handleEdit(product)} className="bg-blue-600 text-white px-4 py-1.5 rounded-lg text-sm font-bold hover:bg-blue-700">Edit</button>
                <button onClick={() => handleRemove(product.id)} className="bg-red-600 text-white px-4 py-1.5 rounded-lg text-sm font-bold hover:bg-red-700">Remove</button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
