import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useStore } from '../store';

export default function AdminOffers() {
  const { currentUser, offers, addOffer, removeOffer } = useStore();
  const navigate = useNavigate();
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');

  if (!currentUser || currentUser.role !== 'admin') {
    navigate('/login'); return null;
  }

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;
    addOffer({
      id: Date.now().toString(),
      title,
      description,
      bannerColor: '#EAB308',
      active: true
    });
    setTitle('');
    setDescription('');
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-6">🔥 Offers & Sales</h1>

      <div className="bg-white rounded-xl shadow-lg p-6 mb-8">
        <h2 className="text-xl font-bold mb-4">Create New Offer</h2>
        <form onSubmit={handleAdd} className="space-y-3">
          <input value={title} onChange={e => setTitle(e.target.value)} placeholder="Offer Title (e.g. FLAT 50% OFF)"
            className="w-full border rounded-lg px-4 py-2 focus:ring-2 focus:ring-yellow-500 focus:outline-none" required />
          <input value={description} onChange={e => setDescription(e.target.value)} placeholder="Description (e.g. On all T-shirts)"
            className="w-full border rounded-lg px-4 py-2 focus:ring-2 focus:ring-yellow-500 focus:outline-none" />
          <button type="submit" className="bg-black text-white px-6 py-2 rounded-lg font-bold hover:bg-gray-800">Create Offer</button>
        </form>
      </div>

      {offers.length === 0 ? (
        <p className="text-gray-500 text-center py-8">No offers created yet</p>
      ) : (
        <div className="space-y-3">
          {offers.map(offer => (
            <div key={offer.id} className="bg-white rounded-xl shadow p-4 flex items-center justify-between">
              <div>
                <p className="font-bold text-lg">🔥 {offer.title}</p>
                <p className="text-sm text-gray-500">{offer.description}</p>
              </div>
              <div className="flex gap-2 items-center">
                <span className={`px-2 py-0.5 rounded-full text-xs font-bold ${offer.active ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-500'}`}>
                  {offer.active ? 'Active' : 'Inactive'}
                </span>
                <button onClick={() => removeOffer(offer.id)} className="bg-red-600 text-white px-3 py-1.5 rounded-lg text-sm font-bold hover:bg-red-700">Remove</button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
