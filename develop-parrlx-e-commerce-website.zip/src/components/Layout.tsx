import { Outlet, Link, useNavigate } from 'react-router-dom';
import { useStore } from '../store';
import { useState } from 'react';

export default function Layout() {
  const { currentUser, cart, logout } = useStore();
  const navigate = useNavigate();
  const [menuOpen, setMenuOpen] = useState(false);

  const isAdmin = currentUser?.role === 'admin';
  const isMember = currentUser?.role === 'member';

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      {/* Top Bar */}
      <header className="bg-black text-white sticky top-0 z-50 shadow-lg">
        <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between">
          <Link to="/" className="flex items-center gap-3" onClick={() => setMenuOpen(false)}>
            <img src="https://i.ibb.co/BHbBt9vB/IMG-.jpg" alt="PARRLX" className="h-10 w-10 rounded-full object-cover border-2 border-white" />
            <span className="text-2xl font-black tracking-widest">PARRLX</span>
          </Link>

          {/* Desktop Nav */}
          <nav className="hidden md:flex items-center gap-6 text-sm font-medium">
            <Link to="/" className="hover:text-yellow-400 transition">Home</Link>
            <Link to="/store" className="hover:text-yellow-400 transition">Store</Link>
            {currentUser && !isAdmin && (
              <>
                <Link to="/track-order" className="hover:text-yellow-400 transition">Track Order</Link>
                <Link to="/order-history" className="hover:text-yellow-400 transition">Order History</Link>
              </>
            )}
            {(isAdmin || isMember) && (
              <Link to="/admin" className="hover:text-yellow-400 transition">Dashboard</Link>
            )}
            <Link to="/cart" className="hover:text-yellow-400 transition relative">
              🛒 Cart
              {cart.length > 0 && (
                <span className="absolute -top-2 -right-4 bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">{cart.length}</span>
              )}
            </Link>
            <Link to="/help" className="hover:text-yellow-400 transition">Help</Link>
            {currentUser ? (
              <div className="flex items-center gap-3">
                <Link to="/profile" className="hover:text-yellow-400 transition">👤 {currentUser.name}</Link>
                <button onClick={() => { logout(); navigate('/'); }} className="bg-red-600 px-3 py-1 rounded text-xs hover:bg-red-700">Logout</button>
              </div>
            ) : (
              <Link to="/login" className="bg-yellow-500 text-black px-4 py-1.5 rounded font-bold hover:bg-yellow-400 transition">Login</Link>
            )}
          </nav>

          {/* Mobile menu button */}
          <button className="md:hidden text-2xl" onClick={() => setMenuOpen(!menuOpen)}>☰</button>
        </div>

        {/* Mobile Nav */}
        {menuOpen && (
          <div className="md:hidden bg-gray-900 px-4 pb-4 space-y-2 text-sm">
            <Link to="/" className="block py-2 hover:text-yellow-400" onClick={() => setMenuOpen(false)}>Home</Link>
            <Link to="/store" className="block py-2 hover:text-yellow-400" onClick={() => setMenuOpen(false)}>Store</Link>
            {currentUser && !isAdmin && (
              <>
                <Link to="/track-order" className="block py-2 hover:text-yellow-400" onClick={() => setMenuOpen(false)}>Track Order</Link>
                <Link to="/order-history" className="block py-2 hover:text-yellow-400" onClick={() => setMenuOpen(false)}>Order History</Link>
              </>
            )}
            {(isAdmin || isMember) && (
              <Link to="/admin" className="block py-2 hover:text-yellow-400" onClick={() => setMenuOpen(false)}>Dashboard</Link>
            )}
            <Link to="/cart" className="block py-2 hover:text-yellow-400" onClick={() => setMenuOpen(false)}>🛒 Cart ({cart.length})</Link>
            <Link to="/help" className="block py-2 hover:text-yellow-400" onClick={() => setMenuOpen(false)}>❓ Help & Support</Link>
            {currentUser ? (
              <>
                <Link to="/profile" className="block py-2 hover:text-yellow-400" onClick={() => setMenuOpen(false)}>👤 {currentUser.name}</Link>
                <button onClick={() => { logout(); navigate('/'); setMenuOpen(false); }} className="bg-red-600 px-3 py-1 rounded text-xs hover:bg-red-700">Logout</button>
              </>
            ) : (
              <Link to="/login" className="block bg-yellow-500 text-black px-4 py-2 rounded font-bold text-center" onClick={() => setMenuOpen(false)}>Login</Link>
            )}
          </div>
        )}
      </header>

      {/* Main Content */}
      <main className="flex-1">
        <Outlet />
      </main>

      {/* Footer */}
      <footer className="bg-black text-gray-400 py-8">
        <div className="max-w-7xl mx-auto px-4 text-center space-y-3">
          <div className="flex items-center justify-center gap-2">
            <img src="https://i.ibb.co/BHbBt9vB/IMG-.jpg" alt="PARRLX" className="h-8 w-8 rounded-full" />
            <span className="text-white text-xl font-black tracking-widest">PARRLX</span>
          </div>
          <p className="text-sm">Premium Clothing Brand | Quality. Style. Confidence.</p>
          <div className="flex justify-center gap-4 text-sm">
            <Link to="/help" className="hover:text-white transition">Help & Support</Link>
            <a href="https://wa.me/919415029404" target="_blank" rel="noreferrer" className="hover:text-white transition">WhatsApp</a>
            <a href="tel:+919335177136" className="hover:text-white transition">Call Us</a>
          </div>
          <p className="text-xs">© 2024 PARRLX. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}
